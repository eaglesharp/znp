

<div class="col-lg-9 footer-aligns">



    <?php

    

    // $users=\App\User::where('id',$search_users->id)->orderBy('created_at','desc')->get();

    

    foreach ($filter_users as $user1) {

        // echo $user1;

    }

    

    ?>



<div class="col-lg-12 candidates_job-dashboard pt-3 pb-2 px-0 pt-0">



<div class="row mx-0 select-all py-3 align-items-center">

<div class="col-lg-3 pb-3 pb-lg-0">

    <div class="col-12 candidates_job-dashboard px-0 pt-0">

        <div class="container">

            <div class="alert alert-success newclass" id="myElem" style="display:none;">Email

                send successfully</div>

        </div>

        <div class="">

            <a id="filter_show-button" class="filter_icon-algin d-block d-lg-none"

                href="javascript:void(0);">



                <img class="filter_img-icon" src="asset/images/Group-1.png">

            </a>

        </div>

        <div class="select_all-check d-flex align-items-center  d-inline">

            <span><input type="checkbox" id="select_all" class="checkbox_size" maxlength="100"

                    required=""><label for="select_all" class="px-2 sign_head_cus mb-0">Select

                    all  <span id="selected_count"></span></label></span>

        </div>

    </div>

</div>

<div class="col-md-9 text-lg-right">

        <button type="submit" class="py-2 signup_button rounded px-2 px-sm-3 mr-0 mb-1 mb-md-0 mr-xl-3"

        onclick="savesearchmodal()" style="
        border-radius: 40px!important;
    ">Save Search</button>

        <input type="hidden" name="filter" value="{{ $filter??'' }}" id="save_filter">

        <!--<button type="submit" class="py-2 signup_button rounded px-2 px-xl-3 mr-0 mb-1 mb-md-0 mr-xl-3"-->

        <!--    data-toggle="modal" data-target="#smsmodal">SMS Candidate</button>-->

        <button type="submit" class="py-2 signup_button rounded px-2 px-sm-3 mr-0 mb-1 mb-md-0 mr-xl-3"

            data-toggle="modal" data-target="#emailmodal" style="
            border-radius: 40px!important;
        ">Send Email</button>

        <button type="submit" class="py-2 signup_button rounded mb-1 mb-md-0 px-2 px-sm-3 " data-toggle="modal"

            data-target="#addfoldermodal" style="
            border-radius: 40px!important;
        ">Add To Folder</button>

</div>

</div>



</div>


{{-- <span class="candidate_title-head">Showing {{count($filter_users)}} <span class="candidate_text">Results</span></span> --}}

<div class="pagiWrap pb-2">

<nav aria-label="Page navigation example">

    @if (isset($filter_users) && count($filter_users))

    {{ $filter_users->appends(request()->query())->links() }} @endif

</nav>

</div>


<div class="job_offers pt-1">





@forelse ($filter_users as $user)

<?php

            

            $todayDate = \Carbon\Carbon::now()->format('Y-m-d');

            

            //    echo($todayDate);

            

            $user_detail = \App\ProfileCityJobsCity::where('user_id', $user->id)->first();

            

            //echo $company;

            

            $summary = \App\ProfileSummary::where('user_id', $user->id)->first();

            

            $notice_period = \App\ProfileNop::where('user_id', $user->id)->first();



            $educations = \App\ProfileEducation::where('user_id', $user->id)->get();

            

            $noticed = isset($notice_period) ? $notice_period->nop_days : '';

            

            //    echo($noticed);

            if(isset($noticed) && !empty($noticed))

            {

            

            if ($noticed == 1) {

                $days = 'Immediately available';

            } elseif ($noticed == 2) {



                $period = $notice_period->last_working_day;

            

                $datetime1 = strtotime($todayDate); // convert to timestamps
                
             

            

                $datetime2 = strtotime($period); // convert to timestamps

            

                if ($datetime1 < $datetime2) {

                    $days = (int) (($datetime2 - $datetime1) / 86400);

                } else {

                    $days = 'Immediately available';

                }

            } elseif ($noticed == 3) {

                $days = 'Buyable Notice Period';

            } else {

                $days = 'Not Under Notice Period';

            }



                

        }

            

            

            // echo($period);

            

            // echo($days);

            

            $data2 = \App\ProfileSummary::where('user_id', $user->id)->first();

            

            $experience = isset($data2) ? $data2->totalexp : '';

            

            $latestdesg = isset($data2) ? $data2->latestdesg : '';

            

            $latestcom = isset($data2) ? $data2->latestcom : '';

            

            //   echo $t

            

            $data3 = \App\ProfileDetails::where('user_id', $user->id)->first();

            

            $ctc = isset($data3) ? $data3->expect_ctc_lakhs : '';

            

            $ectc = isset($data3) ? $data3->expect_ctc_lakhs3 : '';

            

            $user12 = \App\User::where('id', $user->id)->first();



            foreach($educations as $education)

            {



                $high_education = \App\Education::where('id',$education->degree_title)->where('high_value',1)->orWhere('high_value',2)->orWhere('high_value',3)->first();





            }

                    

                    if(isset($high_education))

                    {

                        $final = \App\ProfileEducation::where('user_id', $user->id)->where('degree_title', $high_education->id)->first();

                    }



           

            if(isset($final))

            {

                    $institute = \App\Degree::where('id', $final->organization)->first();

                    $course = \App\Course::where('id', $final->course)->first();

            }



            

            ?>

@php

if(isset($notice_period->last_working_day) && !empty($notice_period->last_working_day))

{        


$date = $notice_period->last_working_day;

$datetime1 = strtotime($todayDate); // convert to timestamps

$datetime2 = strtotime($date); // convert to timestamps



}

$location_values_un =  unserialize($user->prefered_city);



if(isset($location_values_un) && !empty($location_values_un))

{

$count = count($location_values_un);

$two_value = array_slice($location_values_un,0,2);

}









if(isset($two_value) && !empty($two_value))

{

$location_values =  implode(', ', $two_value);

}





@endphp




<div class="boxing  rounded px-4">



<div class="row">



    <div class="col-12 pt-3 select_input_cus">

    <!-- <div class="col-lg-8 col-xl-9 pt-3 select_input_cus"> -->

        <input type="checkbox" class="email_checkbox mail_send-box text-left" value="{{ $user->id }}">

      <ul class="list-inline mb-1 d-flex">

            

            <li class="list-inline-item font_color">

                    <h4 class=" mb-4 mb-sm-0 sign_head ">{{$user->first_name}}</h4>

            </li>
                 @if ($user->verified == 1)
                                        <li class="sign_head list-inline v-icon stick_label">Recruiter Verified</li>
                                         @endif 
                {{-- @if ($user->verified == 2)
                    <li class="sign_head list-inline research">Researched</li>
                @endif  --}}

        </ul> 

        <ul class="list-inline job_view">



            <li class="list-inline-item font_color">{{ $summary->latestdesg??'' }}

            </li>



            <li class="list-inline-item"><span>Latest Company:</span>

                {{ $summary->latestcom??'' }} </li>



            <li class="list-inline-item"><span>Exp:</span> {{ $experience??'' }}</li>



            <li class="list-inline-item"><span>Curr. Location:</span> {{ $user->current_city }}</li>



            @if(isset($location_values)  && !empty($location_values))



            <li class="list-inline-item">



                <span>Pref. Location:</span>



             @if($count > 2)

             {{ $location_values??''}} <span class="candidate_view-more mb-0 " style="color: #197ff3;"

             >More +</span>

             @else

             {{ $location_values??''}}

             @endif



             </li>



             @endif



            <li class="list-inline-item"><span>CTC:</span> {{ $ctc }} LPA</li>



            <li class="list-inline-item"><span>ECTC:</span> {{ $ectc }} LPA</li>



            @if ($days != 0 && isset($datetime1))
            <li class="list-inline-item"><span>Notice Period:</span> {{ $days }}

                @if ($datetime1 < $datetime2) days @endif </li>

                    @else

            <li class="list-inline-item"><span>Notice Period:</span> {{ $days }}

            </li>

            @endif



             <li class="list-inline-item"><span>Highest Education:</span> {{ $course->course??'' }}</li>



            <li class="list-inline-item"><span>Institution:</span> {{$institute->educations??''}}

                    @if(isset($data3->work_type))

                    <li class="list-inline-item pr-5"><span>Pref. Work Type:</span>

                        {{ $data3->work_type??'' }}</li>



                      @endif

            @php

                $interview_date = \App\Interview::where('user_id',$user->id)->where('date','>=',\Carbon\Carbon::now())->orderBy('date','asc');

                $interview_date_list = $interview_date->get();

                $num_count = 0;

                $num_of_items = $interview_date->count();

            @endphp

            

                 @php

                    $interview = [];

                    foreach ($interview_date_list as $melson){

                        



                        if(array_key_exists(date("M", strtotime($melson->date)), $interview)){



                            $interview[date("M", strtotime($melson->date))] = $interview[date("M", strtotime($melson->date))].','.date("d", strtotime($melson->date));

                        }else{           

                            $interview[date("M", strtotime($melson->date))] = date("d", strtotime($melson->date));

                        

                        }

                        

                    }

                    

                    @endphp



                                        @if(isset($interview_date_list) && count($interview_date_list) > 0)

                                        

                                    



                                            <li class="list-inline-item pr-5"><span>Video Interview: </span>

                                            @foreach ($interview as $key => $item)

                                                {{ $key }} {{ $item }}

                                            @endforeach

                                            </li>



                                        @endif

       

        </ul>



        <?php

                        

                        $keyskill = \App\KeySkill::where('user_id', $user->id)

                            ->take(10)

                            ->get();

                        

                        //  $t4=(isset($skill) ? $skill->keyskill:'');

                        

                        //  echo $skill

                        

                        ?>



        <div class="section_2 pb-0">



            <ul class="list-inline">





                @if (count($keyskill) < 10)

                 @foreach ($keyskill as $skill) 

                 <?php

                                        

                 $job_skill = \App\JobSkill::where('id', $skill->keyskill)->first();

                 

              
                 

             

                                        

                 ?>

                  <li class="list-inline-item terms mb-1">





                    @if(str_contains($job_skill->job_skill, $key->job_skill??'') && !empty($key->job_skill))

                   

                   <span style="background-color:yellow">{{ isset($job_skill->job_skill) ? $job_skill->job_skill : '' }} </span> 

                   @else

                   <span >{{ isset($job_skill->job_skill) ? $job_skill->job_skill : '' }} </span> 

                   @endif

                  

                  </li>

                   

                  @endforeach

                    @else

                    @foreach ($keyskill as $skill)

                    <?php

                                        

                    $job_skill = \App\JobSkill::where('id', $skill->keyskill)->first();

                                        

                    ?>







                    <li class="list-inline-item terms mb-1">

                        {{ isset($job_skill->job_skill) ? $job_skill->job_skill : '' }}

                    </li>

                    @endforeach

                    <li class="list-inline-item terms mb-1">

                        <p class="candidate_view-more mb-0 " style="color: #197ff3;"

                            data-toggle="tooltip" data-placement="top"

                            title="To Know more click View Resume">More +</p>

                    </li>

                @endif





            </ul>



        </div>



    </div>





                   <?php

                    

                    $com_id = Auth::guard('company')->user()->id;

                    

                    $company = \App\Company::where('id', $com_id)->first();



                    $unlock = \App\Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->where('unlocked_users_ids',$user->id)->first();

                    

                    ?>



    <!-- <div class="col-lg-3 col-xl-3 align-self-center">



       @if($company->package_end_date > $now)





            <a class="btn btn_style mx-auto mb-3 mt-3 mb-lg-0" data-toggle="tooltip" data-placement="top"

                title="Remaining CV Access : {{ $company->availed_cvs_quota }}/{{ $company->cvs_quota }}"

                href="{{ route('candidate.profile1', $user->id) }}" target="_blank">

                @if($unlock)

                Viewed Resume

                @else

                View Resume

                @endif

            

            </a>

             <button type="submit" class="btn btn_style mx-auto mb-3 mt-2 mb-lg-0" onclick="sendemail({{ $user->id }})">Send Email</button>

            <button type="submit" class="btn btn_style mx-auto mb-3 mt-2 mb-lg-0" onclick="sendsms({{ $user->id }})">Send SMS</button>

          @else

           <a class="btn btn_style mx-auto mb-3 mt-3 mb-lg-0" data-toggle="tooltip" data-placement="top"

                title="Purchase a Plan"

                href="{{ route('pricing') }}" target="_blank">                            

                View Resume                           

            

            </a>

            @endif

            <div class="d-flex justify-content-center align-items-center view-in-resume pt-4">

            <div class="mr-3"><i class="fa fa-eye pr-2"></i><span>{{ $user->no_profile_views??'0' }}</span></div>

            <div><i class="fa fa-download pr-2"></i><span>{{ $user->no_of_downloads??'0' }}</span></div>

        </div>



    </div>   -->

    <div class="col-12 border-top pt-3 mt-3 cv-search-btns">

            <div class="d-md-flex align-items-center justify-content-between">

                <div class="d-flex flex-wrap justify-content-center">

                @if($company->package_end_date > $now)


                                    <a class="btn btn-sent mb-2 mb-sm-0 mr-2" data-toggle="tooltip" data-placement="top"

                                        title="CV Access : {{ $company->availed_cvs_quota }}/{{ $company->cvs_quota }}"

                                        href="{{ route('candidate.profile1', $user->id) }}" target="_blank">

                                        @if($unlock)

                                        <!-- <img class="pr-1" src="{{ asset('asset/images/tick.png') }}"> -->

                                        <i class="fa fa-check mr-2" aria-hidden="true"></i>

                                        Viewed Resume

                                        @else

                                        <i class="fa fa-file-pdf-o  mr-2" aria-hidden="true"></i>View Resume

                                        @endif

                                        
                                    </a>

                                    <button type="submit" class="btn btn-sent mb-2 mb-sm-0 mr-2" data-toggle="tooltip" data-placement="top"

                                    title="Email Quota : {{ $company->availed_email_quota }}/{{ $company->email_quota }}" onclick="sendemail({{ $user->id }})"><i class="fa fa-envelope-o mr-2" aria-hidden="true"></i>Send Email</button>

                                    @if($user->recorded_video)

                                    <button type="submit"  class="btn btn-sent mb-2 mb-sm-0 mr-2"   onclick="recordedmodal({{$user->id}})"

                                            ><i class="fa fa-envelope-o mr-2" aria-hidden="true"></i>View Interview</button>
                                            <input type="hidden" class="modalid{{$user->id}}" value="{{ asset('cvs/'.$user->recorded_video) }}">

                                    @endif      

                    @else

                                    <a class="btn btn-sent mb-2 mb-sm-0 mr-2" data-toggle="tooltip" data-placement="top"

                                        title="Purchase a Plan"

                                        href="{{ route('pricing') }}" target="_blank">                            

                                        <i class="fa fa-file-pdf-o  mr-2" aria-hidden="true"></i>View Resume
                                    </a>

                                  

                                    <button type="submit"  class="btn btn-sent mb-2 mb-sm-0 mr-2" data-toggle="modal" data-target="#alertmodal"

                                            ><i class="fa fa-envelope-o mr-2" aria-hidden="true"></i>View Interview</button>
                                           

                                    

                    @endif
                          

                    <!--<button type="submit" class="btn btn-sent mb-2 mb-sm-0 mr-2" onclick="sendsms({{ $user->id }})"><i class="fa fa-commenting-o mr-2" aria-hidden="true"></i>Send SMS</button>-->

                </div>



                <div class="d-flex justify-content-center align-items-center view-in-resume pt-2 pt-sm-3 pt-md-0">

                    <div class="mr-3"><i class="fa fa-envelope-open pr-2"></i><span>{{ $user->no_profile_views??'0' }}</span></div>

                    <div><i class="fa fa-download pr-2"></i><span>{{ $user->no_of_downloads??'0' }}</span></div>

                </div>

            </div>

        </div>



        <input type="hidden" value="{{  $user->phone??'' }}" id="phone_number" class="phone_number">

    @php

    $now = \Carbon\Carbon::now();

    @endphp


    <div class="joblist">
            @if ($user->layoff_package_end_date > $now)

             <p class="list-inline-item-1 mb-0 layoff-cv" data-toggle="tooltip" data-placement="top"

            title='"Layoff CV" (CV of Jobseeker laid off at work)'>

            Layoff CV</p>
            

            @endif



            @if ($user->package_end_date > $now)

            <p class="list-inline-item mb-0 express-job" data-toggle="tooltip" data-placement="top"

                title='“Xpress Jobseeker” (Jobseeker has updated Video Interview availability)'>

                Xpress Job Seeker</p>

            @endif

            </div>



</div>



</div>



@empty

<h4 style="

        text-align: center;

        font-size: 30px;

    ">

"No Search Results Found!"</h4>

@endforelse







</div>


<div class="pagiWrap pb-2">

<nav aria-label="Page navigation example">

    @if (isset($filter_users) && count($filter_users))

    {{ $filter_users->appends(request()->query())->links() }} @endif

</nav>

</div>
</div>





<!--sms modal Start-->

<div class="container">

<!-- modal -->

<div class="modal newmodalclass" id="savesearchmodal">

<div class="modal-dialog">

<div class="modal-content mx-auto">

    <!-- header -->

    <div class="alert alert-danger print-error-msg" style="display:none">

        <ul></ul>

    </div>



    <form method="post" action="" enctype="multipart/form-data">

        @csrf

        <div class="col-12 pt-3">

            

            <div class="row">

                <div class="col-md-8">

                    <h4 class="modal-title sign_head">Save Search</h4>

                </div>

                <div class="col-md-4">

                    <p type="button" class="info" data-dismiss="modal"><img

                            class="float-right modal_close-icon"

                            src="{{ asset('/') }}asset/images/close.png"></p>

                </div>

            </div>

        </div>

        <!-- body -->

        <div class="modal-body">

            <span class="help-block user_id-error"></span>

            <div class="row">

                <input type="hidden" value="" name="search" id="savesearch">

                 <!-- <input type="hidden" value="" name="location" id="savelocation"> -->

                  <input type="hidden" value="" name="notice_period" id="save_notice_period">
                   @php
                   if (isset($selected)) {
                      $valueString = implode(',', $selected);
                    } else {
                      $valueString = '';
                    }
                    @endphp

                   <input type="hidden" value="{{ $valueString }}" name="location" id="save_location">

               

                <div class="col-md-12 pb-2">

                    <label>Search Name</label>

                   

                   <input type="text" name="search_value" id="search_value" value="" class="form-control">



                        <span class="help-block search_value-error"></span>

                        

                    <span class="text-danger">

                        <strong id="search_value-error" class="new_error_class"></strong>

                    </span>

                </div>

            </div>

        </div>

        <div class="modal-footer justify-content-end px-3">

            <button type="button" class="btn btn-secondary py-2 mr-3" data-dismiss="modal">Cancel</button>

            <button type="button" id="save_form_submit"

                class="signin_button px-4 py-2 emailsend rounded">Save</button>

        </div>

    </form>

</div>

</div>

</div>

</div>
