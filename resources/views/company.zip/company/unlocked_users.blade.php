@extends('layouts.app')







@section('content') 







<!-- Header start --> 

@php
    // Define the selected values

    if(isset($locations_vals)) {

        $selected = $locations_vals;

       
    }
        if(isset($search_vals)) {

        $searchselected = $search_vals;

       
    }



@endphp






@include('includes.header') 


<style>

      .date-in{

            height: 36px !important;

    }
    
    
        .boxing.v-icon.stick_label::after { 

            content: 'Recruiter Verified';
            position: absolute;
            font-size: 12px;
            background: #59a2f3;
            color: #fff;
            top: 5px;
            right: -120px;
            font-family: 'Proximanova-Regular';
            padding: 2px 10px;
            border-radius: 30px;
             width: 117px;

        }
        
  

    .joblist{
        position: absolute;
        right: 0px;
        top: -2px;
    }


    .list-inline-item-1.layoff-cv {
        background-color: #3998de;
        color: #fff !important;
        padding: 2px 7px;
        border-radius:  0 5px 0 10px;
        line-height: 19px;
        font-size: 13px;
        display: inline-block;
    }



    .list-inline-item-1.express-job-1 {

        background-color: #3998de;

        color: #fff !important;

        padding: 2px 7px;

        border-radius:  5px 0 10px;

        position: absolute;

        line-height: 19px;

        font-size: 13px;

        right: 116px;

        top: 0px;

    }

        .notice-period .dropdown-menu {
            height: 96px!important;

        }

        .serach-icon .tokenfield{
                width: 499.172px!important;
                    min-height: 55px!important;
        }

        .location_cus .tokenfield .token{
                border-radius: 30px!important;               
                background-color: #f6faff!important;
                padding: 0px 10px;
                height: 26px!important;
        }

        .notice-period .btn-group{
                width: 100% !important;

        }


        .notice-period button.multiselect.dropdown-toggle.btn.btn-default{
               padding: 7px 35px 5px 15px !important;
               height: 36px !important;
        }

        .date-in{
            height: 40px !important;
        }

        .location_cus .tokenfield {
            min-height: 55px;
        }

        #search_data {
            background-image: unset !important;
            min-height: 55px !important;
            border: 1px solid #ced4da;
        }
        .tokenfield .token .close {
            line-height: 1.1em !important;

        }
        
         .default-size{
            font-size:15px !important;
        }




</style>




<!-- Header end --> 







<!-- Inner Page Title start --> 















<!-- Inner Page Title end -->







<section class="contact_bg-color">



    <div class="container contact_bg-color">



        <div class="row">



            <div class="col-lg-12 text-center py-5">



                <div class="contact_head-color py-1">



                    Unlocked Resumes



                </div>



            </div>



        </div>



    </div>



</section>







<!-- candidate profile -->











<section class="section_search-box  pt-4">



    <div class="container">



            {{-- <form class="col-lg form-inline serach-icon px-2" action="{{route('unlocked.search')}}" method="post">



                @csrf



                <input class="form_control-1 rounded pl-3 pr-5" type="text" placeholder="Search" aria-label="Search" name="search">



                <button class="filter_search-button" type="submit"><img class="search_icon-input pr-0"



                        src="asset/images/loupe.png"></button>



            </form> --}}







                  <form class="row px-2 mt-sm-5" action="{{ route('candidate.unlocked.filter.page') }}" method="post">

                <div class="col-lg form-inline serach-icon location_cus  px-2">

                    @csrf

                    <input class="form_control-1 select-skill rounded pl-3 pr-5" type="text" placeholder="Search" aria-label="Search"

                           name="search[]" value="" id="searchvalue">

                    <button class="filter_search-button" type="submit"><img class="search_icon-input pr-0"

                                                                            src="{{ asset('asset/images/loupe.png') }}"></button>

                </div>

              
                <?php

                $locations = \App\User::all();

                $city = \App\User::orderBy('current_location')

                    ->get()

                    ->whereNotNull('current_location')

                    ->unique('current_location');



                ?>



                <div class="col-lg position_lit px-2 notice-period location_cus">



                    <input id="search_data"  name="location[]" class="form_control rounded pl-3 pr-5 w-100 savelocation" placeholder="Search Location">


                    </input>

                </div>


                <div class="col-lg-1 box px-2">

                    <button type="submit" class="btn btn_submit w-100 text-light">Apply</button>

                </div>

            </form>


        </div>



</section>







<!-- second section -->







<section class="section_candidate-list py-4">



    <div class="container">



        <div class="row">



            <div class="col-lg-3 col-12 scrollbar candidate_filter-sub">



                <div class="candidate_filter-inner">



                    <div class="row d-block d-lg-none">



                        <div class="col-lg candidate_filter-header">



                            <div class="candidate_filter-body candidate_filter-hide py-3 px-2">



                                All Filters



                                <a id="filter_hide-button" class="close_icon-algin" href="javascript:void(0);">



                                    <img class="close_img-icon" src="asset/images/cancel.png">



                                </a>



                            </div>



                        </div>



                    </div>



                    <div class="candidate_list-filter mb-4 mb-md-0 px-0">



                        <div class="accordion" id="accordionExample">



                            <div class="candidate_list mt-2 pt-3">



                                <div class="candidate_head mb-1 px-lg-1" id="headingOne">



                                    <button class="btn_candidate-box btn_candidate-arrow px-3 py-4" type="button"



                                        data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"



                                        aria-controls="collapseOne">



                                        Sub Filters



                                    </button>



                                </div>



                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"



                                    data-parent="#accordionExample">



                                    <div class="candidate_body px-lg-3 py-2">



                                        <div class="form-check pb-2 pl-0 w-100">



                                            <form action="{{route('candidate.unlocked.filter1.page')}}" method="post">



                                              
                                                    @csrf



                                                    <label class="mb-1 pt-0 sign_fontsize">Total Experience<span

                                                                class="text-danger px-1"> </span></label>



                                                    <div class="row py-1">



                                                        <div class="col">

                                                            <input type="number" name="min_exp" placeholder="Min" min="0"

                                                                   max="50" value="{{ isset($min_exp) ? $min_exp : '' }}"

                                                                   onkeyup=imposeMinMax(this)

                                                                   class="w-100 signup_input rounded pl-2 py-1 default-size" id="save_min_exp">

                                                        </div>

                                                        <div class="col-1 text-center px-0 pt-1">-</div>

                                                        <div class="col">

                                                            <input type="number" name="max_exp" placeholder="Max" min="0"

                                                                   max="50" value="{{ isset($max_exp) ? $max_exp : '' }}"

                                                                   onkeyup=imposeMinMax(this)

                                                                   class="w-100 signup_input rounded pl-2 py-1 default-size" id="save_max_exp">

                                                        </div>

                                                    </div>
                                                         @if($errors->has('max_exp'))
                                                         <p class="text-danger">{{ $errors->first('max_exp') }}</p>
                                                         @endif

                                                    <label class="mb-1 pt-0 sign_fontsize">Salary Range<span

                                                                class="text-danger px-1"> </span></label>



                                                    <div class="row py-1">



                                                        <div class="col">

                                                              <input type="number" name="min_salary" placeholder="Min" min="0" max="100"

                                                           onkeyup=imposeMinMax(this) @if(isset($min)) @if($min == 0) @else value="{{ $min }}" @endif @else value="" @endif

                                                           class="w-100 signup_input rounded px-1 py-1 default-size" id="save_min_salary">

                                                                            </div>

                                                                            <div class="col-1 text-center px-0 pt-1">-</div>

                                                                            <div class="col">

                                                                                 <input type="number" name="max_salary" placeholder="Max" min="0" max="100"

                                                           onkeyup=imposeMinMax(this) @if(isset($max)) @if($max == 0) @else value="{{ $max }}" @endif @else value="" @endif

                                                           class="w-100 signup_input rounded px-1 py-1 default-size" id="save_max_salary">

                                                                             



                                                                                
                                                                            </div>

                                                                        </div>

                                                                                @if($errors->has('max_salary'))

                                                                                    <p class="text-danger">{{ $errors->first('max_salary') }}</p>

                                                                                @endif





                                            </div>


                                            <label class="mb-1 pt-0 sign_fontsize">Interview Availability<span

                                                        class="text-danger px-1"> </span></label>


                                            <div class="row py-1">



                                                <div class="col">

                                                    <input type="text" name="previous_start_date" class="form_action date-in rounded pl-2 mb-3 default-size" id="previous_start_date" value="{{ isset($s_date) ? $s_date : '' }}" placeholder="Start Date">


                                                </div>



                                                <div class="col">

                                                    <input type="text" name="previous_end_date" class="form_action date-in rounded pl-2 mb-3" id="previous_end_date default-size" value="{{ isset($e_date) ? $e_date : '' }}" placeholder= "End Date">


                                                    @if($errors->has('previous_end_date'))

                                                        <span class="text-danger">{{ $errors->first('previous_end_date') }}</span>

                                                    @endif

                                                </div>

                                            </div>


                                 <div class="row py-1 notice-period" style="    margin-left: 0px;
                                    width: 100%;
                                    padding-bottom: 15px!important;">

                                                                              <select id="multiple-select-notice" class="form_control  noticeperiodvalue  form_action rounded pl-3 pr-5 mb-3" multiple="multiple" name="notice_period[]">

                                                                            <option value="1" @if (isset($notice_period)) @if (in_array(1, $notice_period)) selected @endif @endif>



                                                                                Immediately Available </option>

                                                                            <option value="2" @if (isset($notice_period)) @if (in_array(2, $notice_period)) selected @endif @endif>Serving

                                                                                Notice Period</option>



                                                                        </select>
                                      </div>

                                        

                                            <?php



                                            $profile_education = isset($profileEducation) ? $profileEducation->degree_title : null;



                                            $educationn = \App\Education::find($profile_education);



                                            $educations = \App\Education::all();



                                            $education = isset($education) ? $education : null;



                                            $education1 = \App\Education::where('id', $education)->first();



                                            ?>



                                            <select class="form_control form_action rounded pl-3 pr-5 mb-3 dynamic "

                                                    name="education" style="height: 35px!important;" id="save_education">



                                                <option value="" selected >

                                                    {{ isset($education1) ? $education1->education : 'Select Education' }}

                                                </option>

                                                <!--<option value="">All</option>-->

                                                @foreach ($educations as $edu)

                                                    <option value="{{ $edu->id }}"> {{ $edu->education }}</option>

                                                @endforeach

                                            </select>





                                            <?php



                                            $organization = isset($course) ? $course : null;



                                            $specilation = isset($specilation) ? $specilation : null;



                                            $course = \App\Course::where('id', $organization)->first();



                                            $spec = \App\specs::where('id', $specilation)->first();



                                            ?>



                                   
                                            <select class="form_control form_action rounded pl-3 pr-5 mb-3" name="gender"

                                                    style="height: 35px!important;" id="save_gender">

                                                <!--<option Selected Disabled>Gender</option>-->

                                                <option value="" >Gender</option>

                                                <option value="2" @if (isset($gender)) @if ($gender=='2' ) selected @endif

                                                        @endif>Male</option>

                                                <option value="1" @if (isset($gender)) @if ($gender=='1' ) selected @endif

                                                        @endif>Female</option>

                                                <option value="3" @if (isset($gender)) @if ($gender=='3' ) selected @endif

                                                        @endif>Don't wish to specify</option>

                                            </select>



                                            <select class="form_control form_action rounded pl-3 pr-5 mb-3"

                                                    name="job_type" style="height: 35px!important;" id="save_job_type">

                                                <!--<option Selected Disabled>Job Type</option>-->

                                                <option value="" >Job Type</option>

                                                <option value="Contract" @if (isset($job_type)) @if ($job_type=='Contract' )

                                                    selected @endif @endif>Contract</option>

                                                <option value="Permanent" @if (isset($job_type)) @if ($job_type=='Permanent'

                                                    ) selected @endif @endif>Permanent</option>

                                                <option  value="Flexible" @if (isset($job_type)) @if ($job_type=='Flexible'

                                                ) selected @endif @endif>Flexible</option>

                                            </select>



                                        </div>



                                        <div class="col-lg-12 box d-block px-0 px-lg-3 mb-1">

                                            <button type="submit" class="btn btn_submit w-100 text-light">Apply</button>

                                        </div>

                                        </form>
                                </div>



                            </div>



                        </div>



                    </div>



                </div>



            </div>







            <!-- candidate listing left part -->



 @if(isset($filter_users))



 @include('company.unlocked-search')

  

@else 



            <div class="col-lg-9">



                <?php 



                    //$users=\App\User::orderBy('created_at','desc')->get();



                ?>



                <div class="col-lg-9 candidates_job-dashboard py-3 px-0 pt-0">



                    <span class="candidate_title-head">Showing {{count($unlocked_users)}} <span class="candidate_text">Candidates</span></span>



                    <a id="filter_show-button" class="filter_icon-algin d-block d-lg-none" href="javascript:void(0);">



                        <img class="filter_img-icon" src="asset/images/Group-1.png">



                    </a>



                </div>



                



                {{-- {{$unlocked_users}} --}}







                <div class="job_offers pt-1">



                    @foreach ($unlocked_users as $user)



                            



                    <?php 



           

                        $keyskill=\App\KeySkill::where('user_id',$user->unlocked_users_ids)->first();  

                   

                        $company=\App\ProfileCityJobsCity::where('user_id',$user->unlocked_users_ids)->first();



                



                    $summary=\App\ProfileSummary::where('user_id',$user->unlocked_users_ids)->first();



                



                    $todayDate = \Carbon\Carbon::now()->format('Y-m-d');



                    



                    $data2=\App\ProfileSummary::where('user_id',$user->unlocked_users_ids)->first();



                    $experience=(isset($data2) ? $data2->totalexp:'');



                    $latestdesg=(isset($data2) ? $data2->latestdesg:'');



                    $latestcom=(isset($data2) ? $data2->latestcom:'');



                



                    //   echo $t



        



                    $data3=\App\ProfileDetails::where('user_id',$user->unlocked_users_ids)->first();



                    $ctc=(isset($data3) ? $data3->expect_ctc_lakhs:'');



                    $ectc=(isset($data3) ? $data3->expect_ctc_lakhs3:'');



        



                    $notice_period=\App\ProfileNop::where('user_id',$user->unlocked_users_ids)->first();



                    // echo($notice_period);



                    $noticed=(isset($notice_period) ? $notice_period->nop_days:'');



                    //    echo($noticed);







                    if ($noticed == 1) 

                {



                



                        $days = 'Immediately available';

                }



                    elseif ($noticed == 2)

                    {



                        $period = $notice_period->last_working_day;



                        $datetime1 = strtotime($todayDate); // convert to timestamps



                        $datetime2 = strtotime($period); // convert to timestamps  





                        if ($datetime1 < $datetime2)

                        {



                             $days = (int)(($datetime2 - $datetime1)/86400);



                        } else {



                            $days = 'Immediately available';



                         }

                           



                    }

                    elseif($noticed == 3) {



                        $days = 'Buyable Notice Period';



                    }



                    else

                    {

                        $days = 'Not Under Notice Period';

                    }



                    $user123 = \App\User::where('id',$user->unlocked_users_ids)->first();


                ?>

               



                @if ($keyskill)



                @php

                $date = $notice_period->last_working_day;

                $datetime1 = strtotime($todayDate); // convert to timestamps    

                $datetime2 = strtotime($date); // convert to timestamps  

                @endphp   

                

                @php

                

               $location_values_un = unserialize((isset($user123->prefered_city) ? $user123->prefered_city:'') );

                                            

              

                

                if($location_values_un)

                {

                



                $count = count($location_values_un);



                $two_value = array_slice($location_values_un,0,2);



                $location_values =  implode(', ', $two_value);

                

                }else{

                

                $count = 0;

                }



                @endphp



                        <div class="boxing ul-resume @if(isset($user123->verified)) @if($user123->verified==1)v-icon stick_label @endif @endif  rounded px-4">

                    <ul class="list-inline pt-3 my-0">

                        <li class="list-inline-item pr-3 font_color">

                            <a href="{{ route('candidate.profile2', $user123->id??'') }}" class="sign_head"><h4>{{$user123->first_name??''}}</h4></a>

                        </li>

                    </ul>

                    <ul class="list-inline my-0">

                        <li class="list-inline-item pr-3">

                            <a href="mailto:{{$user123->email??''}}" class="contact_mail">

                                <i class="fa fa-envelope-o pr-2 text-primary" aria-hidden="true"></i>{{$user123->email??''}}

                            </a>

                        </li>

                        <li class="list-inline-item pr-3">

                            <a href="tel: {{$user123->phone??''}}" class="contact_phone">

                                <i class="fa fa-phone text-primary pr-2" aria-hidden="true"></i> {{$user123->phone??''}}

                            </a>

                        </li>

                        

                    </ul>



                            {{-- <div class="row"> --}}



                                {{-- <div class="col-lg-8 col-xl-9 pt-3"> --}}



                                    <ul class="list-inline job_view">



                                        <li class="list-inline-item font_color">{{$latestdesg??''}}</li>



                                        <li class="list-inline-item"><span>Latest Company:</span> {{$latestcom??''}} </li>



                                        <li class="list-inline-item"><span>Curr. Location:</span> {{ $user123->current_city??'' }}</li>



                                        <li class="list-inline-item">

                

                                            <span>Pref. Location:</span>

                

                                         @if($count > 2)

                                         {{ $location_values??''}} <span class="candidate_view-more mb-0 " style="color: #197ff3;"

                                         >More +</span>

                                         @else

                                         {{ $location_values??''}}

                                         @endif

                

                                         </li>



                                        <li class="list-inline-item"><span>Exp:</span> {{$experience??''}}</li>



                                     



                                        <li class="list-inline-item"><span>CTC:</span> {{$ctc??''}} LPA</li>



                                        <li class="list-inline-item"><span>ECTC:</span> {{$ectc??''}} LPA</li>



                                        @if ($days != 0 && isset($datetime1))



                                        <li class="list-inline-item"><span>Notice Period:</span> {{$days}} @if ($datetime1 < $datetime2)days @endif</li>



                                    @else



                                        <li class="list-inline-item"><span>Notice Period:</span> {{$days}}</li>



                                    @endif    



                                    </ul>



                                    <?php 



                                    $keyskill=\App\KeySkill::where('user_id',$user->unlocked_users_ids)->take(5)->get();



                                    



                                    //  $t4=(isset($skill) ? $skill->keyskill:'');



                                    //  echo $skill



                                    ?>



                                    <div class="section_2 pb-0">



                                        <ul class="list-inline">



                                           

                                        @if(count($keyskill) < 10)



                                                    @foreach($keyskill as $skill)



                                                            <?php                    



                                                            $job_skill=\App\JobSkill::where('id',$skill->keyskill)->first();



                                                            ?>







                                                            <li class="list-inline-item terms mb-1">{{(isset($job_skill->job_skill)? $job_skill->job_skill:'')}}</li>



                                                    @endforeach



                                                    @else 



                                                    @foreach($keyskill as $skill)



                                                        <?php                    



                                                        $job_skill=\App\JobSkill::where('id',$skill->keyskill)->first();



                                                        ?>







                                                        <li class="list-inline-item terms mb-1">{{(isset($job_skill->job_skill)? $job_skill->job_skill:'')}}</li>

                                                        



                                                    @endforeach

                                                        <li class="list-inline-item terms mb-1"><a class="candidate_view-more" href="javascript:void(0);">More +</a></li>



                                        @endif



                                            



                                        </ul>



                                    </div>



                                @php

                                    $now = \Carbon\Carbon::now();

                                @endphp

                                

                                <div class="joblist">
                                    
                                 @isset($user123->layoff_package_end_date)

                                 @if ($user123->layoff_package_end_date > $now)



                                 <p class="list-inline-item-1 mb-0 layoff-cv" data-toggle="tooltip" data-placement="top" title='"Layoff CV" (CV of Jobseeker laid off at work)'>

        

                                Layoff CV</p>

                                
                                @endif
                                
                                @endisset

                                

                                @if(isset($user123->package_end_date))

                                

                                @if($user123->package_end_date >  $now  )

                                    <p class="list-inline-item mb-0 express-job unlocked"  data-toggle="tooltip" data-placement="top" title='“Xpress Jobseeker” (Jobseeker has updated Video Interview availability)'>Xpress Job Seeker</p>

                                @endif  

                                @endif

                                </div>

                        </div>



                        @endif



                    @endforeach

                    <div class="pagiWrap">

                        <nav aria-label="Page navigation example">

                            @if(isset($unlocked_users) && count($unlocked_users))

                            {{ $unlocked_users->links() }} 
                            
                            @endif

                        </nav>

                    </div>

                    



                </div>



            </div>



            @endif



        </div>



</section>











@include('includes.footer')







@endsection



@push('scripts')





<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>


<script>





$.ajaxSetup({



headers: {



    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')



}



});



$('.dynamic').change(function(){



var degree_id = $(this).val(); 







//     alert(degree_id);







if(degree_id){







  $.ajax({



    type:"POST",



    url:"{{url('gety')}}",



    _token: '{{ csrf_token() }}',



    data: {



       degree:degree_id,



    },



    dataType: "json",



    



    success:function(res){        



    if(res){



      $(".dynamiccourse").empty();



      $(".dynamiccourse").append('<option>Select course</option>');

      $("#newcourse123 option:first").attr("disabled", "disabled");



      $.each(res,function(key,value){



        $(".dynamiccourse").append('<option value="'+value.id+'">'+value.course+'</option>');



      });



    



    }else{



      $(".dynamiccourse").empty();



    }



    }



  });



}else{







}   



});











$('.dynamiccourse').on('change',function(){







var course_id = $(this).val();  







if(course_id){



 $.ajax({



   type:"POST",



   url:"{{url('getspecs')}}",



   _token: '{{ csrf_token() }}',



   data: {



      course:course_id,



   },



   dataType:"json",



   success:function(res){        



   if(res){



     $(".dynamicspecs").empty();



     $(".dynamicspecs").append('<option>Select Specilization</option>');

    



$("#specs123 option:first").attr("disabled", "disabled");



     $.each(res,function(key,value){



       $(".dynamicspecs").append('<option value="'+value.id+'">'+value.specs+'</option>');



     });



   



   }else{



     $(".dynamicspecs").empty();



   }



   }



 });



}else{



 $(".dynamicspecs").empty();



}



 



});





$('#multiple-select-notice').multiselect({

    includeSelectAllOption: false,

    nonSelectedText: 'Notice Period',

    numberDisplayed: 2,

});



function getSelectedValues() {

    var selectedVal = $("#multiple-select-notice").val();

    for (var i = 0; i < selectedVal.length; i++) {

        function innerFunc(i) {

            setTimeout(function() {

                location.href = selectedVal[i];

            }, i * 2000);

        }

        innerFunc(i);

    }

}



function show() {



}



$('#multiple-select-notice-responsive').multiselect({

    includeSelectAllOption: false,

    nonSelectedText: 'Choose by Notice Periods',

});



function getSelectedValues() {

    var selectedVal = $("#multiple-select-notice-responsive").val();

    for (var i = 0; i < selectedVal.length; i++) {

        function innerFunc(i) {

            setTimeout(function() {

                location.href = selectedVal[i];

            }, i * 2000);

        }

        innerFunc(i);

    }

}



          // Location multiselect



          $(document).ready(function() {



    //multiselect Location

    $('#location-multi-select').multiselect({

        includeSelectAllOption: true,

       selectAllText: 'Any Location',

        enableFiltering: false,

        enableClickableOptGroups: true,

        enableCollapsibleOptGroups: true,

        nonSelectedText: 'Choose by Location',

        numberDisplayed: 2,

        enableCaseInsensitiveFiltering: true,

        filterPlaceholder: 'Enter Location',

    });



   

    

});



$(document).ready(function () {

$('#previous_start_date').datepicker({

autoclose: true,

format: 'dd-mm-yyyy',

todayHighlight: true,

        startDate: new Date() // set minimum date to today



});

var startDate = new Date('12/1950');

var FromEndDate = new Date();

var ToEndDate = new Date();

ToEndDate.setDate(ToEndDate.getDate() + 365);



$('#previous_start_date').datepicker({

weekStart: 1,

startDate: '01/09/2019',

endDate: FromEndDate,

autoclose: true

})

.on('changeDate', function (selected) {

startDate = new Date(selected.date.valueOf());

startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));

$('#previous_end_date').datepicker('setStartDate', startDate);

});


    $('#previous_end_date').datepicker({
                weekStart: 1,
                startDate: startDate,
                endDate: ToEndDate,
                format: 'dd-mm-yyyy',
                autoclose: true,
                beforeShowDay: function(date){
                    var daysDiff = Math.ceil((date.getTime() - startDate.getTime()) / (1000 * 3600 * 24)); // Calculate days difference
                    if (daysDiff <= 15) {
                        return {enabled: true};
                    } else {
                        return {enabled: false};
                    }
                }
            })
            .on('changeDate', function (selected) {
                FromEndDate = new Date(selected.date.valueOf());
                FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
                $('#previous_start_date').datepicker('setEndDate', FromEndDate);
            });


            // Initialize the tokenfield plugin
            $('#search_data').tokenfield({
              autocomplete: {
                source: function(request, response) {
                  jQuery.get("{{ url('autocomplete/search-location') }}", {
                    query : request.term
                  }, function(data){
                    data = JSON.parse(data);
                    response(data);
                  });
                },
                delay: 100
              },
              showAutocompleteOnFocus: true,
              allowDuplicates: false,
              createTokensOnBlur: false
            });

            @if(isset($locations_vals))
                // Set the selected values
                $('#search_data').tokenfield('setTokens', {!! json_encode($selected) !!});
            @endif



            $('.select-skill').tokenfield({
                delimiter: ',',
                beautify: false
            });


            @if(isset($search_vals))
              // Pre-select the options               
              $('.select-skill').tokenfield('setTokens', {!! json_encode($searchselected) !!} );
            @endif




});

    </script>

    

@endpush