@extends('layouts.app')
@section('content') 
<!-- Header start --> 
@include('includes.header') 
<!-- Header end --> 


<style>
.latestcompany .select2-container--default .select2-selection--single {
    height: initial;
}
.latestcompany .select2-selection__rendered{
    font-size: 15px;
    color: grey!important;
    padding-top: 0.4rem !important;
    padding-bottom: 0.4rem !important;
}
.latestcompany .select2-container--default .select2-selection--single .select2-selection__rendered {
  
    line-height: 28px;
}

.select2-container--default .select2-search--inline .select2-search__field {
     background: white!important; 
 
}
.select2-container--default .select2-selection--multiple {
 
    background-image: none !important;
  
}

#education1,#course1,#specs1,#organization{
    color: #000 !important;
}

.ignore-i i {
    background: #949494;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    color: #fff;
    font-size: 15px;
    line-height: 1.3;
    cursor: pointer;
    text-align: center;
}


.select-box label{
    position: absolute!important;
    bottom: -30px!important;
    left: 0!important;
    z-index: 999!important;
}

#terms_of_use-error{
        left: 15px!important;
}

.toggle-icon{
    position: absolute;
    margin-top: 10px;
    margin-left: -28px;
    cursor: pointer;
}

.university .select2-selection--single{
    height: 37px!important;
}
.university .select2-selection__rendered{
    line-height: 35px!important;
}

.select-skillval .select2-container--default .select2-selection--multiple .select2-selection__choice{
    border-radius: 30px!important;               
                background-color: #f6faff!important;
                padding: 0px 10px;
                height: 26px!important;
}
.select-location .select2-container--default .select2-selection--multiple .select2-selection__choice{
    border-radius: 30px!important;               
                background-color: #f6faff!important;
                padding: 0px 10px;
                height: 26px!important;
}
#my-select-container .select2-search__field {
    padding: 7px 0;
}
#my-select-container  .select2-selection--multiple {
    padding: 5px !important;
}

#my-select-locationcontainer .select2-search__field {
    padding: 7px 0;
}
</style>

<section class="postjob-listing section_signup post-section">

    <div class="container">

        <div class="col-md-12 col-lg-8 m-auto py-5">

            <div class="box py-4 rounded">

                <h5 class="sign_head text-center pt-3 mb-3">Update a <span class=" sign_color">Job</span></h5>


                <form class="px-3 px-sm-5 priceform row"  method="POST" id="updatejob"  action="{{ route('update.front.job',$job->id) }}">

                  
             @csrf

             @method('PUT')
                        

                    <div class="col-lg-6" id="div_company_name1">



                        <input type="hidden" value="" id="plandetail" name="job_title">

                        <p class="sign_fontsize mb-2 pt-3">Job Title<span class="text-danger px-1">*</span></p>

                        <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Job Title" maxlength="100" name="job_title" id="job_title" value="{{ $job->job_title??'' }}">
                        @if ($errors->has('job_title')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('job_title') }} </span> 
                            
                        @endif

                        
                    </div>


                    <div class="col-lg-6">
                     
                        <p class="sign_fontsize mb-2 pt-3">Mode of Work<span class="text-danger px-1">*</span></p>

                    
                        @php
                        $options = [
                            "Work From Office",
                            "Hybrid",
                            "Remote",
                            "WFH during Covid",                          
                        ];
                       @endphp

                        <select id="inputState" class="w-100 py-2 px-3 signin_input rounded" name="work_mode" value="{{ old('work_mode') }}">
                                <option  disabled>--Select--</option>
                                @foreach ($options as $option)
                                <option {{ $job->work_mode == $option ? 'selected' : '' }}>{{ $option }}</option>
                                @endforeach
                        </select>      
                      
                        @if ($errors->has('work_mode')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('work_mode') }} </span> 
                            
                        @endif


                        
                    </div>

                
                    <div class="col-12">

                        <p class="sign_fontsize mb-2 pt-3">Job Type<span class="text-danger px-1">*</span></p>

                    
                        @php
                        $options = [
                            "Full time/Permanent",
                            "Contract",
                            "Contract To Hire",
                            "Internship",                          
                        ];
                       @endphp

                        <select id="job_type" class="w-100 py-2 px-3 signin_input rounded" name="job_type" value="{{ old('job_type') }}">
                                <option selected disabled>--Select--</option>
                                @foreach ($options as $option)
                                <option {{ $job->job_type == $option ? 'selected' : '' }}>{{ $option }}</option>
                                @endforeach
                        </select>      
                      

                       
                        @if ($errors->has('job_type')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('job_type') }} </span> 
                            
                        @endif
                    </div>


                    
                    <div class="col-lg-12 pb-2" id="div_company_name" @if($job->job_type == "Full time/Permanent") style="display: none;" @endif>
                        <input type="hidden" value="" id="plandetail" name="duration">
                    
                        <p class="sign_fontsize mb-2 pt-2">Duration in Months</p>
                    
                        <input type="number" step="any" class="w-100 py-2 px-3 signin_input rounded" placeholder="Duration in months" maxlength="100" name="duration" id="duration" value="{{ old('duration',$job->duration) }}">
                        
                        @if ($errors->has('duration'))
                            <span class="help-block" style="color: red">{{ $errors->first('duration') }}</span>
                        @endif
                    </div>

                    <div class="col-12 mb-2">
                        <p class="sign_fontsize mb-2 pt-3">Job Shift<span class="text-danger px-1">*</span></p>

                        @php
                        $options = [
                            "Day Shift",
                            "UK Shift (1 PM Onwards)",
                            "US Shift (6 PM Onwards)",
                            "Night Shift (9 PM Onwards)",                          
                        ];
                        @endphp

                        <select id="job_shift" class="w-100 py-2 px-3 signin_input rounded" name="job_shift" value="{{ old('job_shift') }}" style="height: 42px;">
                            <option selected disabled>--Select--</option>
                            @foreach ($options as $option)
                            <option {{ $job->job_shift == $option ? 'selected' : '' }}>{{ $option }}</option>
                            @endforeach
                        </select>      

                        @if ($errors->has('job_shift'))
                            <span class="help-block" style="color: red">{{ $errors->first('job_shift') }}</span>
                        @endif
                    </div>


                    <div class="col-12 col-md-12">

                        <label class="sign_fontsize">Skills<span class="text-danger px-1">* </span></label>
                                    <div class="w-100 select-skillval" id="my-select-container">

                                    
                                        <select class="form-control select-box" name="keyskills[]" multiple="multiple" placeholder="Please enter skills or technologies" id="chooseskill">
                   
                                        </select>
                                    
                                    </div>
                            
                                    <span class="error" id="keyskillid"></span>
                                    
                                        
                                        @if ($errors->has('keyskills')) <span class="help-block" style="color: red">
                                            
                                            {{ $errors->first('keyskills') }} </span> 
                                            
                                        @endif


                    </div>

                    <div class="col-lg-12 mt-2">
                            <label class="mb-2 sign_fontsize">Salary Range<span class="text-muted px-1">(Lakhs PA)</span></label>
                    </div>

                    <div class="col-lg-6 pb-3 pb-lg-0 position_lit">
                        <input type="number" step="any" onkeyup="imposeMinMax(this)" min="1" max="100" placeholder="Minimum" class="w-100 pl-3 pr-4 py-2  sign_fontsize  signup_input rounded btnsub1 edit1" name="min_salary" value="{{ $job->min_salary }}">  
                        @if ($errors->has('min_salary')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('min_salary') }} </span> 
                            
                        @endif
                    </div>

                    <div class="col-lg-6  pb-lg-0 position_lit">
                        <input type="number" step="any" onkeyup="imposeMinMax(this)" min="0" max="99" placeholder="Maximum" class="w-100 pl-3 pr-4 py-2 sign_fontsize  signup_input rounded btnsub1 edit1" name="max_salary" value="{{ $job->max_salary }}">
                        @if ($errors->has('max_salary')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('max_salary') }} </span> 
                            
                        @endif
                    </div>

                    <div class="col-lg-6">
                        <p class=" sign_fontsize mb-2 pt-3">Experience<span class="text-danger px-1">*</span>

                        </p>
                        @php
                     $options = [
                            "0-3 Years",
                            "3-5 Years",
                            "5-8 Years",
                            "8-10 Years",
                            "10-13 Years",
                            "13-15 Years",
                            "15-18 Years",
                            "18-20 Years",
                            "20-23 Years",
                            "23-25 Years",
                            "25-28 Years",
                            "28-30 Years",
                            "30-33 Years",
                            "33-35 Years",
                            "35-38 Years",
                            "38-40 Years",
                            "40-43 Years",
                            "43-45 Years",
                            "45-48 Years",
                            "48-50 Years"
                            ];
                    @endphp
                        <select id="inputState" class="w-100 py-2 px-3 signin_input rounded" name="experience" value="">
                                <option disabled>--Select--</option>
                                @foreach ($options as $option)
                                <option {{ $job->experience == $option ? 'selected' : '' }}>{{ $option }}</option>
                            @endforeach
                        </select>                                                                                                                                               
                        @if ($errors->has('experience')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('experience') }} </span> 
                            
                        @endif
                        {{-- <!-- <input type="number" class="w-100 py-2 px-3 signin_input rounded" min="0" max="10" placeholder="Experience" name="Experience" value=""> --> --}}


                    </div>

                    <div class="col-lg-6">
                        <p class=" sign_fontsize mb-2 pt-3">Number Of Openings<span class="text-danger px-1">*</span>

                        </p>

                        <input type="number" class="w-100 py-2 px-3 signin_input rounded" min="0" max="50" placeholder="Number Of Openings" name="no_of_openings" value="{{ $job->no_of_openings }}">
                        @if ($errors->has('no_of_openings')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('no_of_openings') }} </span> 
                            
                        @endif

                    </div>

                    <div class="col-12 select-location"  id="my-select-locationcontainer">
                        <input type="hidden" value="" id="plandetail" name="Location">

                        <p class="sign_fontsize mb-2 pt-3">Location<span class="text-danger px-1">*</span></p>

                        <select class="form-control select-box" name="location[]" multiple="multiple" placeholder="Please enter location" id="locationFilter42">
                   
                        </select>
                    

                        {{-- <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Location" maxlength="100" name="location" id="locationFilter42" value="{{ $job->location }}"> --}}
                        @if ($errors->has('location')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('location') }} </span> 
                            
                        @endif
                   
                    </div>

                    <div class="col-12">

                        <p class="sign_fontsize mb-2 pt-3">Job Description<span class="text-danger px-1">*</span></p>
                        <textarea class="w-100 py-2 px-3 signin_input rounded summernote" placeholder="Job Description"  rows="3" name="job_description">{!! $job->job_description !!}</textarea>
                        @if ($errors->has('job_description')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('job_description') }} </span> 
                            
                        @endif
                        <!-- <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Location" maxlength="100" name="Location" id="Location" value=""> -->
                    </div>

                    <div class="col-12">

                        <p class="sign_fontsize mb-2 pt-3">Job Overview<span class="text-danger px-1">*</span></p>
                        <textarea class="w-100 py-2 px-3 signin_input rounded summernote" placeholder="Roles & Responsibility" id="description" name="job_overview"  rows="3">{!! $job->job_overview !!}</textarea>
                  
                        <!-- <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Location" maxlength="100" name="Location" id="Location" value=""> -->
                        @if ($errors->has('job_overview')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('job_overview') }} </span> 
                            
                        @endif
                    </div>

                    <div class="col-12">

                        <p class="sign_fontsize mb-2 pt-3">Roles & Responsibility<span class="text-danger px-1">*</span></p>
                        <textarea class="w-100 py-2 px-3 signin_input rounded summernote" placeholder="Roles & Responsibility" id="description" name="roles_responsibility"  rows="3">{!! $job->roles_responsibility !!}</textarea>
                    
                        <!-- <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Location" maxlength="100" name="Location" id="Location" value=""> -->
                        @if ($errors->has('roles_responsibility')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('roles_responsibility') }} </span> 
                            
                        @endif
                    </div>

                    <div class="col-12">

                        <p class="sign_fontsize mb-2 pt-3">About Company<span class="text-danger px-1">*</span></p>
                        <textarea class="w-100 py-2 px-3 signin_input rounded " placeholder="About Company" id="description" name="description"  rows="3">{{ old('description',Auth::guard('company')->user()->description) }}</textarea>
                    
                        <!-- <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Location" maxlength="100" name="Location" id="Location" value=""> -->
                        @if ($errors->has('description')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('description') }} </span> 
                            
                        @endif
                    </div>

                    <div class="col-lg-12" >

                        <p class="sign_fontsize mb-2 pt-3">Locality</p>

                        <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Locality" maxlength="100" name="locality" id="locality" value="{{ old('locality',Auth::guard('company')->user()->location) }}">
                  
                        @if ($errors->has('locality')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('locality') }} </span> 
                            
                        @endif

                        
                    </div>



                    <div class="col-lg-12" >

                        <p class="sign_fontsize mb-2 pt-3">Website Address<span class="text-danger px-1">*</span></p>

                        <input type="text" class="w-100 py-2 px-3 signin_input rounded" placeholder="Website Address" maxlength="100" name="website_address" id="website_address" value="{{ old('website_address',$job->website_address??'') }}">
                  
                        @if ($errors->has('website_address')) <span class="help-block" style="color: red">
                                           
                            {{ $errors->first('website_address') }} </span> 
                            
                        @endif

                        
                    </div>





                    <div class="col-12 py-4">
                        <button type="submit" class="w-100 py-2 signup_button rounded">Post Job</button>
                    </div>
                </form>
                <!-- <div class="col-12">

                    <div class="text-center pt-4 sign_fontsize d-none">Already have an account ? <a href="http://127.0.0.1:8000/employer-login">Sign
                            in</a></div>

                </div> -->
                <!-- <div class="col-12">

                    <div class="text-center pt-4 sign_fontsize">Sign up as an Jobseeker <a href="http://127.0.0.1:8000/register">Sign
                            up</a></div>

                </div> -->

            </div>

        </div>
    </div>

</section>


@php
     if(isset($resultdata)) {       

            $selected = $resultdata;

        }

        if(isset($locationresult)) {       

           $locationresultSelected = $locationresult;

        }


@endphp




@include('includes.footer')
@endsection
@push('styles')
<style type="text/css">
    .formrow iframe {
        height: 78px;
    }
</style>
@push('scripts')
<script
    src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=AIzaSyCejQVcKXrBxZGFj0EQpSHkLgOk_Lp6CRI&region=IN">
</script>


<script>

          // Function to show or hide the duration field based on the selected job type
          function toggleDurationField() {
      
            var selectedJobType = document.getElementById('job_type').value;
            var durationField = document.getElementById('div_company_name');
            
            if (selectedJobType === 'Full time/Permanent') {
                // If "Full time/Permanent" is selected, hide the duration field and clear its value
                durationField.style.display = 'none';
                document.getElementById('duration').value = '';
            } else {
                // If any other option is selected, show the duration field
                    durationField.style.display = 'block';
                }
            }

            // Attach an event listener to the dropdown to trigger the toggle function on change
            document.getElementById('job_type').addEventListener('change', toggleDurationField);

            // Call the function once on page load to initialize the state based on the initial value
            // toggleDurationField();



        function checkEmail() {
        var email = $('#email').val();

        $.ajax({
            url: '/check-email',
            type: 'POST',
            data: {'email': email},
            success: function(response) {
                
            if (response.exists) {
               // alert('This email address already exists.');
                $('#error-message').text('This email address already exists.');
            }else{
                $('#error-message').text('');
            }
            },
            error: function(xhr) {
          //      $('#error-message').text('An error occurred: ' + error);
          $('#error-message').text('');
           
           //     alert('Error: ' + xhr.responseText);
          
        }
        });
        }

$(document).ready(function() {


 $('.password-toggle .toggle-icon').click(function() {
    var passwordInput = $(this).prev('input');
    var type = passwordInput.attr('type') === 'password' ? 'text' : 'password';
    passwordInput.attr('type', type);
  if (type === 'password') {
        $(this).find('i').removeClass('fa-eye-slash').addClass('fa-eye');
    } else {
        $(this).find('i').removeClass('fa-eye').addClass('fa-eye-slash');
    }
});


$.validator.addMethod("summernoteEmpty", function (value, element) {
    // Get the Summernote content from the hidden textarea
    var summernoteContent = $(element).summernote('code').trim();
    // Check if the content is empty
    return summernoteContent !== "";
}, "This field is required.");

    





google.maps.event.addListener(autocomplete, 'place_changed', function() {

    var near_place = autocomplete.getPlace();

    var location = $("#autocomplete_reg").val();
    location = location.split(',')[0];
    $('#autocomplete_reg').val(location);

});




});

$(".js-example-tokenizer").select2({
    tags: true,
    placeholder: "Please enter key skills or technologies",
    tokenSeparators: [',']
});



    $('#locationFilter42').select2({
    tags: true, 
    tokenSeparators: [','],
    placeholder: "(Add Location)",
    minimumInputLength: 1, // Set the minimum input length to 2
    ajax: {
        url: "{{ url('autocomplete/search-location-job') }}",
        dataType: 'json',
        delay: 250,
        data: function (params) {
            return {
                q: params.term // Use the input value as the search query
            };
        },
        processResults: function (data) {
            // Transform the data into the format expected by Select2
            return {
                results: $.map(data, function (skill) {
                    return {
                        id: skill.location,
                        text: skill.location
                    };
                })
            };
        },
        cache: true

        
    }
});



var selectedValues = @json($selected);


var selectedValuese = @json($locationresultSelected);


    //console.log(selectedValuese);

    $('#chooseskill').select2({
    tags: true,
    tokenSeparators: [','],
    placeholder: "(Search Skill)",
    minimumInputLength: 1, // Set the minimum input length to 1
    ajax: {
        url: '/search-skills', // Replace this with the URL to your search endpoint
        dataType: 'json',
        delay: 250,
        data: function (params) {
            return {
                q: params.term // Use the input value as the search query
            };
        },
        processResults: function (data) {
            // Transform the data into the format expected by Select2
            return {
                results: $.map(data, function (skill) {
                    return {
                        id: skill.id,
                        text: skill.job_skill
                    };
                })
            };
        },
        cache: true
    }
});
@if(isset($resultdata))
    // Set the selected values
    var selectedValues = {!! json_encode($selected) !!};
    var select = $('#chooseskill');
    for (var id in selectedValues) {
       // console.log(selectedValues[id])
        var option = new Option(selectedValues[id], id, true, true);
        select.append(option).trigger('change');
    }
@endif

@if(isset($resultdata))
    // Set the selected values
    var selectedValues = {!! json_encode($locationresultSelected) !!};

    // Get the select element by its ID
    var select = $('#locationFilter42');

    // Clear existing options (optional)
    select.empty();

    // Loop through the selectedValues array
    for (var i = 0; i < selectedValues.length; i++) {
        // Create a new option element with the value and text from selectedValues
        // The 'true' arguments indicate that the option is both selected and default selected
        var option = new Option(selectedValues[i], selectedValues[i], true, true);
        
        // Append the option to the select element
        select.append(option).trigger('change');
    }
@endif


            

$(".js-example-tags").select2({
                            tags: true
                          });


$('body').on('keyup', '.js-input-mobile', function() {
    var $input = $(this),
        value = $input.val(),
        length = value.length,
        inputCharacter = parseInt(value.slice(-1));

    if (!((length > 0 && inputCharacter >= 0 && inputCharacter <= 10) || (length === 1 && inputCharacter >= 7 &&
            inputCharacter <= 10))) {
        $input.val(value.substring(0, length - 1));
    }
});


$.ajaxSetup({

headers: {

  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

}

});


$('.dynamic').change(function(){

// alert('heloo');

var degree_id = $(this).val(); 


// var oldCourse = "{{ old('course') }}";

//alert(oldCourse);

});



</script>

<script>  
        $(document).ready(function() { 

            $('textarea.summernote').summernote({   
                placeholder: 'Write Your Message',  
                tabsize: 2, 
                height: 100,    
                toolbar: [  
                    // ['style', ['style']],   
                    ['font', ['bold', 'italic', 'underline', 'clear']], 
                    // ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']], 
                    //['fontname', ['fontname']],   
                    // ['fontsize', ['fontsize']],  
                    // ['color', ['color']],   
                    ['para', ['ul', 'ol', 'paragraph']],    
                    // ['height', ['height']],  
                    // ['table', ['table']],    
                    // ['insert', ['link']],   
                    // //['view', ['fullscreen', 'codeview']],  
                    // ['help', ['help']]   
                ],  
            }); 
        }); 

        var searchInput = 'autocomplete10';



$(document).ready(function() {

    $location_input = $("#autocomplete10");

    var autocomplete;

    autocomplete = new google.maps.places.Autocomplete((document.getElementById(searchInput)), {

        types: ['(cities)'],


        componentRestrictions: {

            country: "IN"

        }

    });



    google.maps.event.addListener(autocomplete, 'place_changed', function() {

        var near_place = autocomplete.getPlace();

        var location = $("#autocomplete10").val();
        location = location.split(',')[0];
        $('#autocomplete10').val(location);

    });

});
    </script> 

    
@endpush
