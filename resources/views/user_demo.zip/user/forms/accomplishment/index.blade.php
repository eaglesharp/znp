<?php                     

   $accomplishments = \App\Accomplishment::where('user_id',$user->id)->get();

?>       


<div id="Accomplishment" class="col-lg-6 pb-3 px-0 pt-4 mt-0 mt-md-3 profile_head rounded">

    <div class="myprofile_font">Accomplishment</div>  

</div>

<div class="box_profile px-4 px-sm-5 py-4 py-sm-4 rounded">

    <div class="row ">

        <div class="col-12">   

            <div class="myprofile_font">Online Profile</div>  

            <p>Add link to online profiles (e.g. Linkedin, Github etc.).</p> 

            <div class="">

                    @foreach($accomplishments as $acc)

                    
                        <p class="my-0 sign_fontsize"><span>Social Profile Name: </span>{{$acc->profile_name}}  <a href="javascript:void(0)"><i

                            class="fa fa-pencil pl-2 pt-3" onclick="editfrontaccomplishment({{$acc->id}})" aria-hidden="true"></i></a><a href="javascript:void(0)" ><i

                                class="fa fa-trash pl-2 pt-3" aria-hidden="true" onclick="delete_front_accomplishment({{$acc->id}})"></i></a></p>

                        <p class="my-0 sign_fontsize"><span>URL : </span>{{$acc->profile_url}} </p>

                        <p class="my-0 sign_fontsize"><span>Description : </span>{!! $acc->description !!}</p>

                        


                @endforeach

                <p id="success_id53"  class="p-success px-0"></p>

            </div>

            {{-- <div class="myprofile_font">Work Sample</div>  

            <p>Add link to online profiles (e.g. Linkedin, Facebook etc.).</p> 

            <div class="">

                    @foreach($accomplishments as $acc)

                    
                        <p class="my-0 sign_fontsize"><span>Social Profile Name: </span>{{$acc->profile_name}}  <a href="javascript:void(0)"><i

                            class="fa fa-pencil pl-2 pt-3" onclick="editfrontaccomplishment({{$acc->id}})" aria-hidden="true"></i></a><a href="javascript:void(0)" ><i

                                class="fa fa-trash pl-2 pt-3" aria-hidden="true" onclick="delete_front_accomplishment({{$acc->id}})"></i></a></p>

                        <p class="my-0 sign_fontsize"><span>URL : </span>{{$acc->profile_url}} </p>

                        <p class="my-0 sign_fontsize"><span>Description : </span>{!! $acc->description !!}</p>

                        


                @endforeach

                <p id="success_id53"  class="p-success px-0"></p>

            </div> --}}
            
       
        </div>

    </div>

    <a href="#" title="Add Accomplishment" class="project_add" data-toggle="modal"

        data-target="#accomplishment_add">ADD</a>

</div>



<!-- certification modal -->

@include('user.forms.accomplishment.accomplishment_modal')



<div class="modal" id="edit_accomplishment_modal" role="dialog">

    @include('user.forms.accomplishment.accomplishment_edit_modal')
</div>





@push('scripts') 



<script type="text/javascript">



function submitaccomplishmentform() {
   

        var form = $('#add_accomplishment');

        $.ajax({

        url     : form.attr('action'),

                type    : form.attr('method'),

                data    : form.serialize(),

                dataType: 'json',

                success : function (json){

               // alert('success');

               $('#acc_success').html('<p class="alert alert-success">' + 'Accomplishment Updated Successfully ' + '</p>');

               setTimeout(function() { $("#acc_success").hide(); }, 5000);

                location.reload(true);


                },

                error: function(json){

                

                //alert('error');

                if (json.status === 422) {

                var resJSON = json.responseJSON;

                $('.help-block').html('');

                $.each(resJSON.errors, function (key, value) {

                $('.' + key + '-error').html('<strong class="new_error_class">' + value + '</strong>');

                $('#div_' + key).addClass('has-error');

                });

                } else {

                // Error

                // Incorrect credentials

                // alert('Incorrect credentials. Please try again.')

                }

                }

        });

        }







    function editfrontaccomplishment(accomplishment_id){
  
    $("#edit_accomplishment_modal").modal();

    loadaccomplishmentEditForm(accomplishment_id);

    }



    function loadaccomplishmentEditForm(accomplishment_id){



    $.ajax({



    type: "POST",



            url: "{{ route('get.front.accomplishment.edit.form', $user->id) }}",



            data: {"accomplishment_id": accomplishment_id, "_token": "{{ csrf_token() }}"},



            datatype: 'json',



            success: function (json) {



            $("#edit_accomplishment_modal").html(json.html);



           

            }



    });



    }

    

    

    function updateaccomplishmentform() {

        var form = $('#edit_accomplishment');

        $.ajax({

        url     : form.attr('action'),

                type    : form.attr('method'),

                data    : form.serialize(),

                dataType: 'json',

                success : function (json){

               // alert('success');

               $('#success_id21').html('<p class="alert alert-success">' + 'Accomplishment Updated Successfully ' + '</p>');

               setTimeout(function() { $("#success_id21").hide(); }, 5000);

                location.reload(true);

                },

                error: function(json){

                

                //alert('error');

                if (json.status === 422) {

                var resJSON = json.responseJSON;

                $('.help-block').html('');

                $.each(resJSON.errors, function (key, value) {

                $('.' + key + '-error').html('<strong class="new_error_class">' + value + '</strong>');

                $('#div_' + key).addClass('has-error');

                });

                } else {

                // Error

                // Incorrect credentials

                // alert('Incorrect credentials. Please try again.')

                }

                }

        });

        }





    $("#year_of_passing_id option:first").attr("disabled","disabled");

    

    $("#month_of_passing_id option:first").attr("disabled","disabled");  

    

    $("#duration_id option:first").attr("disabled","disabled");

    

    

    function delete_front_accomplishment(id) {

        if (confirm('Are you sure! you want to delete?')) {

        $.post("{{ route('delete.front.accomplishment.detail') }}", {id: id, _method: 'DELETE', _token: '{{ csrf_token() }}'})

                .done(function (response) {

                if (response == 'ok')

                {

              

                } else

                {

                    $('#success_id53').html('<p class="alert alert-success">' + 'accomplishment Deleted Successfully ' + '</p>');
                   location.reload(true);

                }

                });

        }

        }

    



</script>



@endpush