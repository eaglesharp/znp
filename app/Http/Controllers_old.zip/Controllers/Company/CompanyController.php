<?php



namespace App\Http\Controllers\Company;

use App\CompanyVerify;

use App\ProfileCityJobsCity;

use Mail;

use Hash;

use URL;

use App\ProfileSummary;

use App\SaveSearch;

use App\JobSkill;

use App\Template;

use Illuminate\Support\Facades\Auth;

use App\Draft;

use Response;

use File;

use Illuminate\Support\Facades\Session;

use App\Jobs\SendBulkQueueEmail;

use ImgUploader;

// use Auth;

 use Validator;

use App\ProfileDetails;

use DB;

use Input;

use Redirect;

use App\Subscription;

use Newsletter;

use App\User;

use App\Company;

use App\CompanyMessage;

use App\ApplicantMessage;

use App\Country;

use App\CountryDetail;

use App\State;

use App\City;

use App\Unlocked_users;

use App\Industry;

use App\FavouriteCompany;

use App\Package;

use App\FavouriteApplicant;

use App\OwnershipType;

use App\JobApply;

use Carbon\Carbon;

use App\Helpers\MiscHelper;

use App\Helpers\DataArrayHelper;

use App\Http\Requests;

use App\Mail\CompanyContactMail;

use App\Mail\ApplicantContactMail;

use Illuminate\Http\Request;

use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests\Front\CompanyFrontFormRequest;

use App\Http\Controllers\Controller;

use App\Traits\CompanyTrait;

use App\Traits\Cron;

use Illuminate\Support\Str;

use App\Collection;

use App\CollectionList;
use App\EmployerPayment;

use App\Location;

class CompanyController extends Controller

{



    use CompanyTrait;

    use Cron;



    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function __construct()

    {

        $this->middleware('company', ['except' => ['companyDetail', 'sendContactForm']]);

        //FExpi$this->runCheckPackageValidity();

    }

    



    

    

    public function viewPublicProfile(Request $request,$id)

    {
   


    

$c_id=Auth::guard('company')->user()->id;

      //  dd($c_id);

$com = Company::where('id',$c_id)->first();

$now = Carbon::now();

$end_date = $com->package_end_date;


$user_id = User::where('id',$id)->first();



// dd($user_id->verified);



$balance = $com->cvs_quota-$com->availed_cvs_quota;



$email_balance = $com->email_quota-$com->availed_email_quota;



$normal_cv_balance = $com->normal_cv_access-$com->availed_normal_cv_access;



$verified_cv_balance = $com->verified_cv_access-$com->availed_verified_cv_access;



$cvsSearch = Auth::guard('company')->user();

      // dd($cvsSearch);

     

 $unlock = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->where('unlocked_users_ids',$id)->first();





      $collections= Collection::where('user_id',Auth::guard('company')->user()->id)->get();

      //dd($unlocked);


      if($end_date > $now )
    
    {

    


      if(empty($unlock))

      {
       


                        $unlock = new Unlocked_users();

                        $unlock->company_id  = Auth::guard('company')->user()->id;

                        $unlock->unlocked_users_ids  = $id;

                        $unlock->save();

                         $com->availed_verified_cv_access += 1;

                        $com->availed_cvs_quota += 1;

                        $com->save();

               

          }else{
             // dd($unlock);
          }


        $user = User::findOrFail($id);

        // $user_view=new User();

        // $user->no_of_views = 1;

        // $user->

      

            $no_profile_views = $user->no_profile_views + 1;

            $user->no_profile_views = $no_profile_views;

            $user->update();


        $profileCv = $user->getDefaultCv();



        return view('user.applicant_profile')

                        ->with('user', $user)

                        ->with('profileCv', $profileCv)

                        ->with('page_title', $user->getName())

                        ->with('form_title', 'Contact ' . $user->getName())

                        ->with('collections',$collections);

                        

                    }else{


                        return redirect()->back() ->with('alert', 'Your Package Expired!');


                    }           

                      

    }

      
    public function viewPublicProfile2(Request $request,$id)

    {

  //  return dd($request);


  $user = User::findOrFail($id);
    

$c_id=Auth::guard('company')->user()->id;

      //  dd($c_id);

$com = Company::where('id',$c_id)->first();

$now = Carbon::now();

$end_date = $com->package_end_date;


$user_id = User::where('id',$id)->first();



// dd($user_id->verified);



$balance = $com->cvs_quota-$com->availed_cvs_quota;



$email_balance = $com->email_quota-$com->availed_email_quota;



$normal_cv_balance = $com->normal_cv_access-$com->availed_normal_cv_access;



$verified_cv_balance = $com->verified_cv_access-$com->availed_verified_cv_access;



$cvsSearch = Auth::guard('company')->user();

      // dd($cvsSearch);

     

 $unlock = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->where('unlocked_users_ids',$id)->first();





      $collections= Collection::where('user_id',Auth::guard('company')->user()->id)->get();

      //dd($unlocked);

      $profileCv = $user->getDefaultCv();



        return view('user.applicant_profile')

                        ->with('user', $user)

                        ->with('profileCv', $profileCv)

                        ->with('page_title', $user->getName())

                        ->with('form_title', 'Contact ' . $user->getName())

                        ->with('collections',$collections);

                        
  

                      

    }



    public function index()

    {

        return view('company_home');

    }

    public function company_listing()

    {

        $data['companies']=Company::paginate(20);

        return view('company.listing')->with($data);

    }

    public function collections()

    {

        // return dd( Auth::guard('company')->user()->id);

        $collections= Collection::where('user_id',Auth::guard('company')->user()->id)->get();

        // return dd($collections);

        $collection_list= CollectionList::all();

        // return dd($collections);

        // return view('collectionsbulkmail',compact('collections'));

        // return dd($collections);

        return view('company.folders.addfolder.addfolder',compact('collections','collection_list'));

                        // ->with('collections', $collections);

        // return dd($collections)

        // ->with('collections', $collections);

        // return view('collections');

    }

    public function addcollections()

    {

       

        return view('addcollections');

                       

        

    }

    public function editcollection(Request $request,$id)

    {

        $collection= Collection::where('user_id',Auth::guard('company')->user()->id)->where('id',$id)->first();

        // return dd($collection);

        if($collection)

        {

            return view('company.folders.addfolder.editcollection',compact('collection'));

        }

        else

        {

            abort(403);

        }

      

                       

        

    }

    public function storecollection(Request $request)

    {

        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);
        if ($validator->passes()) {
            $collection = new Collection();
            $collection->user_id = Auth::guard('company')->user()->id;
            $collection->name =$request->name;
            $collection->description =$request->description;
            $collection->save();

            return response()->json(array('success' => true, 'status' => 200), 200);

            // return back()->with('message','Collection created successfully');
        }
        return response()->json(['errors'=>$validator->errors()->all()]);
     

    }

    public function updatecollection(Request $request)

    {

        // dd($request->all());

        $validator = Validator::make($request->all(), [
            'name' => 'required',
        ]);

        // return dd($request->all());

        if ($validator->passes()) {

            $collection= Collection::where('user_id',Auth::guard('company')->user()->id)->where('id',$request->id)->first();

            // dd($collection);

            $collection->user_id = Auth::guard('company')->user()->id;

            $collection->name =$request->name;

            $collection->description=$request->description;

            $collection->save();

            return response()->json(array('success' => true, 'status' => 200), 200);

        }
        return response()->json(['errors'=>$validator->errors()->all()]);

    }

    public function gotodeletemodal(Request $request,$id)

    {

        $collection= Collection::where('user_id',Auth::guard('company')->user()->id)->where('id',$id)->first();

        if($collection)

        {

            return view('company.folders.addfolder.deletecollection',compact('collection'));

        }

        // $collection->delete();

        // return back();

    }

    public function deletecollection(Request $request,$delete_id)

    {

              ///dd('hello');



        $collection= Collection::where('user_id',Auth::guard('company')->user()->id)->where('id',$delete_id)->first();

        if($collection)

        {

            $collection->delete();

            

            //return view('company.folders.addfolder.deletecollection',compact('collection'));

        }

        return back()->with('message','Folder Deleted Successfully');

        // $collection->delete();

        // return back();

    }

    public function collectionsbulkmail($id)

    {

        session()->forget('search');
        // return dd( Auth::guard('company')->user()->id);

        $folder_id = $id;

        $collections= CollectionList::where('collection_id',$id)->paginate(100);


        // return dd($collections);

        return view('collectionsbulkmail',compact('collections','folder_id'));



        // return dd($collections);

        // ->with('collections', $collections);

        // return view('collections');

    }

    







    public function companyProfile()

    {

        $countries = DataArrayHelper::defaultCountriesArray();

        $industries = DataArrayHelper::defaultIndustriesArray();

        $ownershipTypes = DataArrayHelper::defaultOwnershipTypesArray();

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        return view('company.edit_profile')

                        ->with('company', $company)

                        ->with('countries', $countries)

                        ->with('industries', $industries)

                        ->with('ownershipTypes', $ownershipTypes);

    }

    public function sendbulkemail(Request $request)
    {

       //  return dd($request->all());
        // $emails = $request->users;
        $company1 = Company::findOrFail(Auth::guard('company')->user()->id);

        $email_balance = $company1->email_quota-$company1->availed_email_quota;

        if($email_balance > 0)

        {

            if($request->name != null)
            {
                $validator = Validator::make($request->all(), [
                    'user_id'=>'required',
                    'name' => 'required_without:template|regex:/^[\pL\s\-]+$/u|max:255',
                    'template' => 'required_without:name',
                    'subject' => 'required',
                    'description' => 'required',
                ],[
                    'user_id.required'=>'
                     Note: Choose at least one candidate to send email.',
            
                    'name.required'  => 'Template name is required',
            
                    'subject.required'  => 'Subject is required',
            
                    'description.required'  => 'Description is required'
                ]);
            
            
            }else{
            
                $validator = Validator::make($request->all(), [
                    'user_id'=>'required',
                    'name' => 'required_without:template|max:255',
                    'template' => 'required_without:name',
                    'subject' => 'required',
                    'description' => 'required',
                ],[
                    'user_id.required'=>'
                     Note: Choose at least one candidate to send email.',
            
                    'name.required'  => 'Template name is required',
            
                    'name.required_without' => 'Template name is required',
            
                    'subject.required'  => 'Subject is required',
            
                    'description.required'  => 'Description is required'
                ]);
            
            }
    
        if ($validator->passes()) {

            if($request->name)
            {
                $template = new Template();
                $template->templatename = $request->name;
                $template->subject = $request->subject;
                $template->message = $request->description;
                $template->company_id = Auth::guard('company')->user()->id;
                $template->save();
            }





            $company = Company::findOrFail(Auth::guard('company')->user()->id);
            // return dd($company);
            $name =  $company->name;
            $companymail  =$company->email;

            $emails = $request->user_id;
            $email= (explode(",",$emails));

            if (isset($email)) {

                $users = User::whereIn('id',$email)->get();
               // return dd($users);

                // foreach ($users as $user_mail) {
                $data = array(
                    'heading' => $request->subject,
                    'message1' =>  $request->description,
                    'companyname' => $name,
                    'companymail' => $companymail,
                    'email'=>$users
                );
               // return dd($data);
               	// send all mail in the queue.
               	  foreach ($users as $user) {
                   Mail::send('emails.template1',$data,function($message)use($data,$user,$companymail,$name)
                   {
                       $message->from($companymail,$name);
                       $message->bcc($user->email);
                       $message->subject($data["heading"]);
                    });
                  }

               

                $collection_list=CollectionList::whereIn('user_id',$email)->get();
                // return dd($collection_list);
                foreach ($collection_list as $list) {
                    $list->emailed=1;
                    $list->save();
                }

                $company->availed_email_quota=$company->availed_email_quota+count($email);
                $company->save();

                return response()->json(array('success' => true, 'status' => 200), 200);
            }
        }
        return response()->json(['errors'=>$validator->errors()]);

    }
    
    
    else{

      //  return Response::json(array('name' => 'Pakainfo', 'state' => 'GJ'));

        return response()->json(['errors1'=>'Upgrage Your Plan']);
      //  return response()->json(array('error1' => true, 'status' => 422), 422);


    }


    }



    // Search functionality



    public function candidateListing()
    {
        session()->forget('search');
        $users = \App\User::orderBy('created_at', 'desc')

                                ->paginate(100);

        return view("company.candidate_listing",compact('users'));

    }





    public function updateCompanyProfile(CompanyFrontFormRequest $request)

    {

    

    

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        /*         * **************************************** */

        if ($request->hasFile('logo')) {

            $is_deleted = $this->deleteCompanyLogo($company->id);

            $image = $request->file('logo');

            $fileName = ImgUploader::UploadImage('company_logos', $image, $request->input('name'), 300, 300, false);

            $company->logo = $fileName;

        }

        /*         * ************************************** */

        $company->name = $request->input('name');

        $company->email = $request->input('email');

        if (!empty($request->input('password'))) {

            $company->password = Hash::make($request->input('password'));

        }

        $company->ceo = $request->input('ceo');

        $company->industry_id = $request->input('industry_id');

        $company->ownership_type_id = $request->input('ownership_type_id');

        $company->description = $request->input('description');

        $company->location = $request->input('location');

        $company->map = $request->input('map');

        $company->no_of_offices = $request->input('no_of_offices');

        $website = $request->input('website');

        $company->website = (false === strpos($website, 'http')) ? 'http://' . $website : $website;

        $company->no_of_employees = $request->input('no_of_employees');

        $company->established_in = $request->input('established_in');

        $company->fax = $request->input('fax');

        $company->phone = $request->input('phone');

        $company->facebook = $request->input('facebook');

        $company->twitter = $request->input('twitter');

        $company->linkedin = $request->input('linkedin');

        $company->google_plus = $request->input('google_plus');

        $company->pinterest = $request->input('pinterest');

        $company->country_id = $request->input('country_id');

        $company->state_id = $request->input('state_id');

        $company->city_id = $request->input('city_id');

		$company->is_subscribed = $request->input('is_subscribed', 0);

		

        $company->slug = Str::slug($company->name, '-') . '-' . $company->id;

        $company->update();

		/*************************/

		Subscription::where('email', 'like', $company->email)->delete();

		if((bool)$company->is_subscribed)

		{			

			$subscription = new Subscription();

			$subscription->email = $company->email;

			$subscription->name = $company->name;

			$subscription->save();

			/*************************/

			Newsletter::subscribeOrUpdate($subscription->email, ['FNAME'=>$subscription->name]);

			/*************************/

		}

		else

		{

			/*************************/

			Newsletter::unsubscribe($company->email);

			/*************************/

		}



        

        flash(__('Company has been updated'))->success();

        return \Redirect::route('company.profile');

    }



    public function addToFavouriteApplicant(Request $request, $application_id, $user_id, $job_id, $company_id)

    {

        $data['user_id'] = $user_id;

        $data['job_id'] = $job_id;

        $data['company_id'] = $company_id;



        $data_save = FavouriteApplicant::create($data);

        flash(__('Job seeker has been added in favorites list'))->success();

        return \Redirect::route('applicant.profile', $application_id);

    }



    public function removeFromFavouriteApplicant(Request $request, $application_id, $user_id, $job_id, $company_id)

    {

        $data['user_id'] = $user_id;

        $data['job_id'] = $job_id;

        $data['company_id'] = $company_id;

        FavouriteApplicant::where('user_id', $user_id)

                ->where('job_id', '=', $job_id)

                ->where('company_id', '=', $company_id)

                ->delete();



        flash(__('Job seeker has been removed from favorites list'))->success();

        return \Redirect::route('applicant.profile', $application_id);

    }



    public function companyDetail(Request $request, $company_slug)

    {

        $company = Company::where('slug', 'like', $company_slug)->firstOrFail();

        /*         * ************************************************** */

        $seo = $this->getCompanySEO($company);

        /*         * ************************************************** */

        return view('company.detail')

                        ->with('company', $company)

                        ->with('seo', $seo);

    }



    public function sendContactForm(Request $request)

    {

        $msgresponse = Array();

        $rules = array(

            'from_name' => 'required|max:100|between:4,70',

            'from_email' => 'required|email|max:100',

            'subject' => 'required|max:200',

            'message' => 'required',

            'to_id' => 'required',

            'g-recaptcha-response' => 'required|captcha',

        );

        $rules_messages = array(

            'from_name.required' => __('Name is required'),

            'from_email.required' => __('E-mail address is required'),

            'from_email.email' => __('Valid e-mail address is required'),

            'subject.required' => __('Subject is required'),

            'message.required' => __('Message is required'),

            'to_id.required' => __('Recieving Company details missing'),

            'g-recaptcha-response.required' => __('Please verify that you are not a robot'),

            'g-recaptcha-response.captcha' => __('Captcha error! try again'),

        );

        $validation = Validator::make($request->all(), $rules, $rules_messages);

        if ($validation->fails()) {

            $msgresponse = $validation->messages()->toJson();

            echo $msgresponse;

            exit;

        } else {

            $receiver_company = Company::findOrFail($request->input('to_id'));

            $data['company_id'] = $request->input('company_id');

            $data['company_name'] = $request->input('company_name');

            $data['from_id'] = $request->input('from_id');

            $data['to_id'] = $request->input('to_id');

            $data['from_name'] = $request->input('from_name');

            $data['from_email'] = $request->input('from_email');

            $data['from_phone'] = $request->input('from_phone');

            $data['subject'] = $request->input('subject');

            $data['message_txt'] = $request->input('message');

            $data['to_email'] = $receiver_company->email;

            $data['to_name'] = $receiver_company->name;

            $msg_save = CompanyMessage::create($data);

            $when = Carbon::now()->addMinutes(5);

            Mail::send(new CompanyContactMail($data));

            $msgresponse = ['success' => 'success', 'message' => __('Message sent successfully')];

            echo json_encode($msgresponse);

            exit;

        }

    }



    public function sendApplicantContactForm(Request $request)

    {

        $msgresponse = Array();

        $rules = array(

            'from_name' => 'required|max:100|between:4,70',

            'from_email' => 'required|email|max:100',

            'subject' => 'required|max:200',

            'message' => 'required',

            'to_id' => 'required',

        );

        $rules_messages = array(

            'from_name.required' => __('Name is required'),

            'from_email.required' => __('E-mail address is required'),

            'from_email.email' => __('Valid e-mail address is required'),

            'subject.required' => __('Subject is required'),

            'message.required' => __('Message is required'),

            'to_id.required' => __('Recieving applicant details missing'),

            'g-recaptcha-response.required' => __('Please verify that you are not a robot'),

            'g-recaptcha-response.captcha' => __('Captcha error! try again'),

        );

        $validation = Validator::make($request->all(), $rules, $rules_messages);

        if ($validation->fails()) {

            $msgresponse = $validation->messages()->toJson();

            echo $msgresponse;

            exit;

        } else {

            $receiver_user = User::findOrFail($request->input('to_id'));

            $data['user_id'] = $request->input('user_id');

            $data['user_name'] = $request->input('user_name');

            $data['from_id'] = $request->input('from_id');

            $data['to_id'] = $request->input('to_id');

            $data['from_name'] = $request->input('from_name');

            $data['from_email'] = $request->input('from_email');

            $data['from_phone'] = $request->input('from_phone');

            $data['subject'] = $request->input('subject');

            $data['message_txt'] = $request->input('message');

            $data['to_email'] = $receiver_user->email;

            $data['to_name'] = $receiver_user->getName();

            $msg_save = ApplicantMessage::create($data);

            $when = Carbon::now()->addMinutes(5);

            Mail::send(new ApplicantContactMail($data));

            $msgresponse = ['success' => 'success', 'message' => __('Message sent successfully')];

            echo json_encode($msgresponse);

            exit;

        }

    }



    public function postedJobs(Request $request)

    {

        $jobs = Auth::guard('company')->user()->jobs()->paginate(10);

        return view('job.company_posted_jobs')

                        ->with('jobs', $jobs);

    }



    public function listAppliedUsers(Request $request, $job_id)

    {

        $job_applications = JobApply::where('job_id', '=', $job_id)->get();



        return view('job.job_applications')

                        ->with('job_applications', $job_applications);

    }



    public function listFavouriteAppliedUsers(Request $request, $job_id)

    {

        $company_id = Auth::guard('company')->user()->id;

        $user_ids = FavouriteApplicant::where('job_id', '=', $job_id)->where('company_id', '=', $company_id)->pluck('user_id')->toArray();

        $job_applications = JobApply::where('job_id', '=', $job_id)->whereIn('user_id', $user_ids)->get();



        return view('job.job_applications')

                        ->with('job_applications', $job_applications);

    }



    public function applicantProfile($application_id)

    {



        $job_application = JobApply::findOrFail($application_id);

        $user = $job_application->getUser();

        $job = $job_application->getJob();

        $company = $job->getCompany();

        $profileCv = $job_application->getProfileCv();



        /*         * ********************************************** */

        $num_profile_views = $user->num_profile_views + 1;

        $user->num_profile_views = $num_profile_views;

        $user->update();

        /*         * ********************************************** */

        return view('user.applicant_profile')

                        ->with('job_application', $job_application)

                        ->with('user', $user)

                        ->with('job', $job)

                        ->with('company', $company)

                        ->with('profileCv', $profileCv)

                        ->with('page_title', 'Applicant Profile')

                        ->with('form_title', 'Contact Applicant');

    }



    public function userProfile($id)

    {



        $user = User::findOrFail($id);

        $profileCv = $user->getDefaultCv();



        /*         * ********************************************** */

        $num_profile_views = $user->num_profile_views + 1;

        $user->num_profile_views = $num_profile_views;

        $user->update();

        /*         * ********************************************** */

        $collections= Collection::where('user_id',Auth::guard('company')->user()->id)->get();

        return view('user.applicant_profile')

                        ->with('user', $user)

                        ->with('profileCv', $profileCv)

                        ->with('page_title', 'Job Seeker Profile')

                        ->with('form_title', 'Contact Job Seeker')->with('collections',$collections);

    }

    public function companyFollowers()

    {

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        $userIdsArray = $company->getFollowerIdsArray();

        $users = User::whereIn('id', $userIdsArray)->get();



        return view('company.follower_users')

                        ->with('users', $users)

                        ->with('company', $company);

    }

    public function addtocollection(Request $request)

    {

        $check = CollectionList::where('collection_id',$request->collection_id)->where('user_id',Auth::guard('company')->user()->id)->where('resume_id',$request->resume_id)->first();

        if(empty($check))

        {

            $collection = new CollectionList();

            $collection->user_id = Auth::guard('company')->user()->id;

            $collection->resume_id =$request->resume_id;

            $collection->collection_id =$request->collection_id;

            $collection->save();

            flash(__('Add to Collection'))->success();

            return back();

        }

        else

        {

            flash(__('Already in Collection'))->success();

            return back();

        }

    }



    public function companyMessages()

    {

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        $messages = CompanyMessage::where('company_id', '=', $company->id)

                ->orderBy('is_read', 'asc')

                ->orderBy('created_at', 'desc')

                ->get();



        return view('company.company_messages')

                        ->with('company', $company)

                        ->with('messages', $messages);

    }



    public function companyMessageDetail($message_id)

    {

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        $message = CompanyMessage::findOrFail($message_id);

        $message->update(['is_read' => 1]);



        return view('company.company_message_detail')

                        ->with('company', $company)

                        ->with('message', $message);

    }



    

    public function resume_search_packages()



    {

        //dd('yrdy');

        $data['packages'] = Package::where('package_for', 'cv_search')->get();

      

        //dd(Auth::guard('company')->user()->cvs_package_id);

        if (Auth::guard('company')->user()->cvs_package_id > 0) {

            $data['success_package'] = Package::findorfail(Auth::guard('company')->user()->cvs_package_id);

        } else {

            $data['success_package'] = '';

        }

        //return dd( $data['success_package']);

        //dd($data['success_package']);

        return view('company_resume_search_packages')->with($data);

    }

    public function unlocked_users()

    {

        $data = array();
        $unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->paginate(100);

        session()->forget('search');
        return view('company.unlocked_users',compact('unlocked_users'));

    }



    public function unlock($user_id)

    {

        $cvsSearch = Auth::guard('company')->user();

        if (null !== ($cvsSearch)) {

            if ($cvsSearch->availed_cvs_ids != '') {



                $newString = $this->addtoString($cvsSearch->availed_cvs_ids, $user_id);

            } else {

                $newString = $user_id;

            }



            $cvsSearch->availed_cvs_ids  = $newString;

            $cvsSearch->availed_cvs_quota += 1;

            $cvsSearch->update();



            $unlock = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->first();

            if (null !== ($unlock)) {

                $unlock->unlocked_users_ids  = $newString;

                $unlock->update();

            } else {

                $unlock = new Unlocked_users();



                $unlock->company_id  = Auth::guard('company')->user()->id;

                $unlock->unlocked_users_ids  = $newString;

                $unlock->save();

            }

            return redirect()->back();

        } else {

            return redirect('/company-packages');

        }

    }

    function addtoString($str, $item)

    {

        $parts = explode(',', $str);

        $parts[] = $item;



        return implode(',', $parts);

    }





    public function resumes(Request $request,$id)

    {

   //return dd($request);

   $no_of_downloads=0;

   $user= User::where('id',$id)->first();

   $exp = ProfileSummary::where('user_id',$user->id)->first();

   $user->no_of_downloads=$no_of_downloads + 1;

   $user->save();

   $company = Company::where('id',Auth::guard('company')->user()->id)->first();
   $company->no_of_downloads = $company->no_of_downloads + 1;
   $company->save();

// dd('test');

    //return $user->resume;


   $myFile = public_path('cvs/'.$user->resume);
   $headers = ['Content-Type: application/pdf'];
   $newName = 'ZNP_'.$user->first_name.'_'.$exp->totalexp.'.pdf';


  // return response()->download($myFile, $newName, $headers);

   //return response()->file($myFile);
   

    return response()->download(public_path('cvs/'.$user->resume,'user'));

   // 'cvs', $cv_file, $request->input('title')

    

    }
    public function invoice(Request $request,$id)

    {



   $payment= EmployerPayment::where('payment_id',$id)->first();

// dd($payment);
   //return $payment->resume;

    return response()->download(public_path('invoices/'.$payment->invoice));

   // 'cvs', $cv_file, $request->input('title')

    

    }



    public function candidatelistsearch(Request $request)

    {



        

        $sea = $request->search;





        //dd($sea);



        // $users = User::whereHas('profileNop', function($q){

        //     $q->where('buyable_nop', $sea);

        // })->get();



     //  $test = ProfileCityJobsCity::where ('current_desigination', 'LIKE', '%' . $sea . '%' )->get ();

//

    //    $users = User::whereHas('ProfileCityJobsCity', function($q) use ($sea){

    //        $q->where('current_company', $sea)->get();

    //    });



    //    $categories = User::whereHas('ProfileCityJobsCity', function($query) use ($sea)

    //    {

    //      //  $query->whereIn('current_company', $sea);

    //        $query->where('current_desigination',$sea);

    //    })

    //        ->get();

        // $showcampaign = User::query()

        //     ->whereHas('ProfileCityJobsCity',function(\Illuminate\Database\Eloquent\Builder $query) use ($sea){

        //         return $query->where('current_designation', 'LIKE','%'.$sea.'%');



        //     })



        //     ->get();

        $users = User::whereHas('ProfileCityJobsCity', function($q){

            $q->where('buyable_nop', 2);

        })->get();

        // $users = User::whereHas('profileNop', function($q){

        //     $q->where('buyable_nop', 3);

        // })

        // // ->whereHas('profileSkills',function($h){

        // //     $h->whereIn('job_skill_id', [3,16]);

        // // })

        // ->where('current_location','kasturi')->get();



        dd($users);

    }





        public function employerdashboard()

    {

        $company = Company::findOrFail(Auth::guard('company')->user()->id);



        $balance = $company->cvs_quota-$company->availed_cvs_quota;

        $email_balance = $company->email_quota-$company->availed_email_quota;

//        dd($balance);



        return view('company.company_dashboard',compact('company','balance','email_balance'));

    }



    public function emailsend(Request $request)

    {

      //  dd($request->all());

        $company = Company::findOrFail(Auth::guard('company')->user()->id);
        
        $companyname = $company->name;
        $companyemail = $company->email;
        

        $email_balance = $company->email_quota-$company->availed_email_quota;

      // dd($email_balance);



       if($email_balance > 0)

       {

        $user= User::where('id',$request->id)->first();

        
        if($request->name != null)
            {
                //dd('name');
                $validator = Validator::make($request->all(), [
                   
                    'name' => 'required_without:template|regex:/^[\pL\s\-]+$/u|max:255',
                    'template' => 'required_without:name',
                    'subject' => 'required',
                    'message' => 'required',
                ],[
                  
                    'name.required'  => 'Template name is required',
            
                    'subject.required'  => 'Subject is required',
                    
                    'template.required_without' => 'Template name is required',
            
                    'message.required'  => 'Message is required'
                ]);
            
            
            }else{
            
                $validator = Validator::make($request->all(), [
                 
                    'name' => 'required_without:template|max:255',
                    'template' => 'required_without:name',
                    'subject' => 'required',
                    'message' => 'required',
                ],[
                  
                    'name.required'  => 'Template name is required',
            
                    'template.required_without' => 'Template name is required',
            
                    'subject.required'  => 'Subject is required',
            
                    'message.required'  => 'Message is required'
                ]);
            
            }
   
        if ($validator->passes()) {
            
            
            if($request->name)
            {
                $template = new Template();
                $template->templatename = $request->name;
                $template->subject = $request->subject;
                $template->message = $request->message;
                $template->company_id = Auth::guard('company')->user()->id;
                $template->save();
            }
            

            $data = [
                'title'    => $user->email,
                'subject'  => $request->subject,
                'messages'  => $request->message,

            ];

            \Illuminate\Support\Facades\Mail::send('emails.send_message', $data, function($message) use ($data,$companyemail,$companyname) {	
                $message->from($companyemail,$companyname);	
               $message->bcc($data['title'])	
                   ->subject($data['subject']);	
           });

            $user->no_of_emails=$user->no_of_emails+1;
            $user->save();
// dd($request->id);
            $collection_list=CollectionList::where('user_id',$request->id)->where('company_id',$company->id)->first();
            //dd($collection_list);
            if($collection_list)
            {
                $collection_list->emailed=1;
                $collection_list->save();
            }
            

            $company->availed_email_quota= $company->availed_email_quota+1;
            $company->save();

            return response()->json(array('success' => true, 'status' => 200), 200);

        }
        return response()->json(['errors'=>$validator->errors()]);

    }else{

       

        return response()->json(['errors1'=>'Upgrage Your Plan']);
    
          //  return redirect()->back()->with('alert', 'Your Email Access Limit is Exceed');
    
        }

   

    }



public function homesearch(Request $request)

{

   

    $company_id = Auth::guard("company")->user()->id;

    $company = Company::where('id',$company_id)->first();

    $now = Carbon::now();

    if($company->package_end_date > $now)
    {

        $company->search = $company->search+1;
        $company->save();

        if($request->location)
        {

             $location = $request->location;

        }else{

            $location = NULL;

        }

    
    $notice_period = $request->notice_period;
    $keyskill = $request->skill;
    
  // dd($keyskill);


    if($request->location)
    {

        $users = User::whereHas('profilekeyskill', function($q) use($keyskill){

              if (in_array(null, $keyskill, true) || in_array('', $keyskill, true)) {
       
            }else{
                  $t = [];
                foreach($keyskill as $skill)
                {
                   $t = explode(",",$skill);
                }  
               // dd($t);
                
                foreach($t as $skill)
                 {
                     $job_skill = JobSkill::where('job_skill','like',"%{$skill}%")->first();
                   
                    if($job_skill)
                    {
                         $q->where('keyskill', $job_skill->id);
                    }
                   
                 }
          }
        
              })->whereHas('profileNop', function($q) use($notice_period,$location){
        
                    if($notice_period)
                    {
                        $q->whereIn('nop_days', $notice_period);
                    }
        
        
           })->whereIn('current_city', $location)->take(5)->get();
  }else{
      

   $users = User::whereHas('profilekeyskill', function($q) use($keyskill){

    // if($keyskill)
    // {
    //     $q->whereIn('keyskill', $keyskill);
    // }
      if (in_array(null, $keyskill, true) || in_array('', $keyskill, true)) {
       
            }else{
             //   dd('skill is coming');
             
              $t = [];
                foreach($keyskill as $skill)
                {
                   $t = explode(",",$skill);
                }  
               // dd($t);
                
                foreach($t as $skill)
                 {
                     $job_skill = JobSkill::where('job_skill','like',"%{$skill}%")->first();
                   
                    if($job_skill)
                    {
                         $q->where('keyskill', $job_skill->id);
                    }
                   
                 }
       
                //  foreach($keyskill as $skill)
                // {
                //  $split = explode(",",$skill);

                //  foreach($split as $skill)
                //  {
                //      dd($skill);
                //      $job_skill = JobSkill::where('job_skill','like',"%{$skill}%")->first();
                //     $q->where('keyskill', $job_skill->id);
                //  }
                
                // }
          }

      })->whereHas('profileNop', function($q) use($notice_period,$location){

            if($notice_period)
            {
                $q->whereIn('nop_days', $notice_period);
            }


   })->take(5)->get();
  }


              $view = view('welcome-search',compact('users'))->render();
              return response()->json(['users'=>$view]);
             
      
       
    }else{
        
        return response()->json(array('error' => true, 'status' => 400), 400);
    }



}


// Candidate First search


public function search(Request $request)
{
   // dd($request);
   
$search = $request->search;

  $search_users = User::whereHas('profileSummary', function($q) use($search){
            $q->where('latestdesg', $search);
        })->get();


        return view("company.candidate_listing",compact('search_users','search'));

}

public function candidatesearch(Request $request)
{
    // dd($request->all());

    if($request->max_salary && $request->min_salary)
    {
        $request->validate([

            'min_salary'  => 'numeric',
      
            'max_salary'  => 'numeric|gt:min_salary',
      
          ],
      [
          'max_salary.gt' => 'Max may not greater than min value'
      ]);
    }



    $search12 = Session::get('search');

      $company_id = Auth::guard("company")->user()->id;

    $company = Company::where('id',$company_id)->first();

    $now = Carbon::now();

    if($company->package_end_date > $now)
    {

        $company->search = $company->search+1;
        $company->save();
        


    if($request->method()=='POST')
    {
        $search = $request->search;
        $search2 = $search;
       
        $new1 = $request->max_salary;
        $max = (int)$new1;
        
        $new = $request->min_salary;
        $min = (int)$new; 
            
            
        // $location1 = $request->location;
        // $notice_period = $request->notice_period;
        if($request->location)
        {
            $location1 = $request->location;
        }
        else
        {
             $location1 =NULL;
        }
        if($request->notice_period)
        {
           $notice_period = $request->notice_period;
        }
        else
        {
                $notice_period =NULL;
        }
        
        if($request->min_salary)
        {
            $new = $request->min_salary;
            $min = (int)$new;
        }
        else
        {
            $min = 0;
            
        }


    if($location1)
    {
    


    $query = User::latest();
 
    if($search)
    { 

         $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min || $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
    if($location1)
    {
        // foreach($location1 as $location)
        //         {
        //        // dd($location);
        //         $location_val = Location::where('location','like',"%{$location}%")->first();
               
        //           $location_id[] = $location_val->id;
        //         }
        // $query->whereHas('userlocation', function($q) use($location1){
            $query->whereIn('current_city', $location1);
    // });
       
    }

 $filter_users = $query->paginate(100);
       
   }else{
       
    //   dd('no location value');


        $query = User::latest();
 
        if($search)
        { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

        }
       


    
        if($min || $max)
        {
            
            //dd('value is there');
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }
      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
        }


     $filter_users = $query->paginate(100);
     
   //  dd($filter_users);

  
  
   }

    
    
    Session::put('filter_users', $filter_users );// $this->filter2search($filter1_users);
    
     $search1 = Session::put('search', $search );
        //return dd($search1);
    
    Session::put('min1', $min );
    
    Session::put('max1', $max );
    
  
    
    Session::put('notice_period', $notice_period );


    $filter = 1;


    if(isset($location_id))
    {
            $location1 = $location_id;
    }
  
    $location2 = $request->location;
    Session::put('location1', $location2);
    
   // dd($min);
   
    //  dd($location1);
 
    
    return view("company.candidate_listing",compact('filter_users','search1','min','max','location1','notice_period','filter'));
    
    }

    if($request->method()=='GET')
    {
        $search = Session::get('search');       
        $min = Session::get('min1');
        $max = Session::get('max1');
        $location1 = Session::get('location1');
       // dd($location1);
        $notice_period = Session::get('notice_period');
      
    
    
    if($location1)
    {
             
    $query = User::latest();
 
   if($search)
    { 

         $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

                    if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                         $q->where('latestdesg','like', '%' . $search . '%');
                    
                    
                          });

                     }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min && $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
    if($location1)
    {
        foreach($location1 as $location)
                {
                // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });

         $query->whereIn('current_city', $location1);
       
    }


  

 $filter_users = $query->paginate(100);
    
     
}else{
   
 
   $query = User::latest();
 
        if($search)
        { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

        }
       




    
        if($min && $max)
        {
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }

      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
                
    
        }


 $filter_users = $query->paginate(100);
    
    
}
     
     $search1 = Session::put('search', $search );

        $filter = 1;

    if(isset($location_id))
    {
            $location1 = $location_id;
    }

 

    return view("company.candidate_listing",compact('filter_users','search1','min','max','location1','notice_period','filter'));
    


    }
   
    }else{

       // return redirect('candidate-filter1-search')->with('plan_exp_msg',0);
      
        return redirect()->back()->with('plan_exp_msg',0);
    }


}
  

// Candidate Second search

public function filter2search(Request $request)
{
    
   // dd($request->all());

    if($request->max_exp)
    {
        $request->validate([

            'min_exp'  => 'numeric',
      
            'max_exp'  => 'numeric|gt:min_exp',
      
          ],
      [
          'max_exp.gt' => 'Max may not greater than min value'
      ]);
    }



  
   Session::forget('search');

   $company_id = Auth::guard("company")->user()->id;

   $company = Company::where('id',$company_id)->first();

   $now = Carbon::now();

   if($company->package_end_date > $now)
   {
       

        $company->search = $company->search+1;
        $company->save();   


if($request->method()=='POST')
    {
      //  dd('post method');


       
        $exp = $request->min_exp;
        if($exp)
        {
            $min_exp = (int)$exp;
        }else{
            $min_exp = '';
        }
        
        $exp1 = $request->max_exp;
          if($exp)
        {
           $max_exp = (int)$exp1;
        }else{
            $max_exp = '';
        }
        
        $interview = $request->interview_avail;
        $education = $request->education;
        $course = $request->course;
        $specilation = $request->specilation;
        $gender = $request->gender;
        $job_type = $request->job_type;
        $filter_resume = $request->filter_resume;
        $s_date = $request->previous_start_date;
        $e_date = $request->previous_end_date;
        if($request->previous_start_date)
        {
            $startDate = date("Y-m-d", strtotime($request->previous_start_date));
        }else{
            $startDate = '';
        }
        if($request->previous_end_date)
        {
            $endDate = date("Y-m-d", strtotime($request->previous_end_date));
        }else{
            $endDate = '';
        }
        
       
        $now = \Carbon\Carbon::now();

       // dd($startDate);

        $today = \Carbon\Carbon::now()->format('Y-m-d');      
        $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');
      
      
     // $use = User::where('package_end_date','>',$now)->where('complete','>=',13)->get()->dd();
         
          $query = User::latest();
          
          if($min_exp && $max_exp)
          {
              $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){
      
              $q->whereBetween('totalexp', [$min_exp,$max_exp]);
          
            });
          }
          
          if($education)
          {
                $query->whereHas('profileEducation', function($q) use($education){
                
                $q->where('degree_title', $education);
              
            });
          }
      
          if($course)
          {
                
               $query->whereHas('profileEducation', function($q) use($course){
               
               $q->where('course', $course);
             
             });
          }
      
              if($specilation)
              {
                  $query->whereHas('profileEducation', function($q) use($specilation){
                  $q->where('specilation', $specilation);
              });
              }
      
              if($job_type)
              {
                  $query->whereHas('profileDetails', function($q) use($job_type){
                      $q->where('work_type', $job_type);
              });
              }
      
              if($gender)
              {
              //  dd($gender);
                  $query->where('gender_id', $gender);
              }
      
      
      
              if($startDate)
              {
               //  dd($startDate);
       
                 // dd($today);
                  $query->whereHas('interViews', function($q) use($startDate,$endDate){
                      $q->whereBetween('date', [$startDate, $endDate]);
                 // dd($q);
              });
              
                 
              }
             

            if($filter_resume == '1')
            {
                $query->where('verified', 1);

            }
            if($filter_resume == '2')
            {
                $query->where('verified', 0);
            }
            if($filter_resume == '3')
            {
                $query->where('package_end_date','>',$now);
            }
      
          
          $filter_users = $query->paginate(100);
  //  dd($filter_users);


        Session::put('min_exp', $min_exp );
       
      //  Session::put('min1', $min );
        
        Session::put('max_exp', $max_exp );
        
        Session::put('interview_avail', $interview );
        
        Session::put('education', $education );
 
        Session::put('course', $course );
        
        Session::put('specilation', $specilation );
        
        Session::put('gender', $gender );
        
        Session::put('startDate', $startDate );
        
        Session::put('endDate', $endDate );
 
        Session::put('job_type', $job_type );

        Session::put('filter_resume', $filter_resume );

        $filter = 2;
      
      
      return view("company.candidate_listing",compact('filter_users','min_exp','max_exp','interview','education','job_type','gender','course','specilation','filter_resume','filter','s_date','e_date'));



    }
    
    if($request->method()=='GET')
    {
        $min_exp = Session::get('min_exp');
        $max_exp = Session::get('max_exp');
        $interview = Session::get('interview_avail');
        $education = Session::get('education');
        $course = Session::get('course');
        $specilation = Session::get('specilation');
        $gender = Session::get('gender');
        $job_type = Session::get('job_type');
        $filter_resume = Session::get('filter_resume');
        $startDate = Session::get('startDate');
        $endDate = Session::get('endDate');
        


        $now = \Carbon\Carbon::now();
      
  
        $today = \Carbon\Carbon::now()->format('Y-m-d');
      
        $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');
      
      

      
         
          $query = User::latest();
          
          
      
          //dd($query);
      
      
          if($min_exp && $max_exp)
          {
          $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){
      
          $q->whereBetween('totalexp', [$min_exp,$max_exp]);
          
          });
      }
          
                  if($education)
              {
                  $query->whereHas('profileEducation', function($q) use($education){
                  $q->where('degree_title', $education);
              });
              }
      
              if($course)
              {
                  $query->whereHas('profileEducation', function($q) use($course){
                  $q->where('course', $course);
              });
              }
      
              if($specilation)
              {
                  $query->whereHas('profileEducation', function($q) use($specilation){
                  $q->where('specilation', $specilation);
              });
              }
      
              if($job_type)
              {
                  $query->whereHas('profileDetails', function($q) use($job_type){
                      $q->where('work_type', $job_type);
              });
              }
      
              if($gender)
              {
                  $query->where('gender_id', $gender);
              }
      
      
              if($startDate)
              {
                 //dd($startDate);
       
                 // dd($today);
                  $query->whereHas('interViews', function($q) use($startDate,$endDate){
                      $q->whereBetween('date', [$startDate, $endDate]);
                 // dd($q);
              });
              
                 
              }

              if($filter_resume == '1')
            {

                $query->where('verified', 1);

          
            }
            if($filter_resume == '2')
            {
                $query->where('verified', 0);
            }
            if($filter_resume == '3')
            {
               
              
                    $query->where('package_end_date','>',$now);
           
            }
      
          
          $filter_users = $query->paginate(100);

                $filter = 2;
      
      


      
      
      return view("company.candidate_listing",compact('filter_users','min_exp','max_exp','interview','education','job_type','gender','course','specilation','filter','startDate','endDate'));

    }

}else{
      
    return redirect()->back()->with('plan_exp_msg',0);
}


  
 

}












/************************************************  Unlocked Users       ************************************ */









public function search1(Request $request)

{

 //  dd('ghello');

$search = $request->search;



$emails = $request->user_id;





// $ids; // array of ids

// $placeholders = implode(',',array_fill(0, count($ids), '?')); // string for the query



// Operation::whereIn('id', $ids)

//    ->orderByRaw("field(id,{$placeholders})", $ids)->get();

     

//$data=array();



 $unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->get();





 



 foreach($unlocked_users as $unlock)

 {



     $data[] = $unlock->unlocked_users_ids;

     

 }



  //dd($data);



  $search_users = User::whereHas('profileSummary', function($q) use($search)
  {

            $q->where('latestdesg', $search);

            $search = $request->search;

        

        })->whereIn('id', $data)->get();



    //dd($search_users);

        return view("company.unlocked_users",compact('search_users'));



}







public function unlockedfiltersearch1(Request $request)

{


    if($request->max_salary)
    {
        $request->validate([

            'min_salary'  => 'numeric',
      
            'max_salary'  => 'numeric|gt:min_exp',
      
          ],
      [
          'max_salary.gt' => 'Max may not greater than min value'
      ]);
    }


if($request->method() == 'POST')
{


   // dd('posrt');

    $unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->get();

    foreach($unlocked_users as $unlock)

    {

   

        $data[] = $unlock->unlocked_users_ids;

        

    }

  
  if(count($unlocked_users) > 0)
  {
  

    $search = $request->search;

    $emails = $request->user_id;

    $unlocked13 = $request->min_salary;

    $unlocked14 = $request->max_salary;

    $min = (int)$unlocked13;
   
    $max = (int)$unlocked14;
    
    
    

    

    // $location1 = $request->location;

    // $notice_period = $request->notice_period;

    if($request->location)
    {
        $location1 = $request->location;
    }
    else
    {
         $location1 =NULL;
    }
    if($request->notice_period)
    {
       $notice_period = $request->notice_period;
    }
    else
    {
            $notice_period =NULL;
    }

    //dd($location1);

    if($location1)
    {


        $query = User::whereIn('id', $data);
 
        if($search)
        { 
    
             $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });
    
        }
    
        if($min && $max)
        {
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }
    
      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
                
    
        }
        if($location1)
    {
    //     foreach($location1 as $location)
    //             {
    //            // dd($location);
    //             $location_val = Location::where('location','like',"%{$location}%")->first();
               
    //               $location_id[] = $location_val->id;
    //             }
    //     $query->whereHas('userlocation', function($q) use($location1){
    //         $q->whereIn('location', $location1);
    // });

    $query->whereIn('current_city', $location1);
       
    }
    
     $filter_users = $query->paginate(100);

    }else{

        $query = User::whereIn('id', $data);
 
       if($search)
       { 

          $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {
           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
       });
               
   
       }


    $filter_users = $query->paginate(100);

    }



   Session::put('filter_users', $filter_users );// $this->filter2search($filter1_users);

    Session::put('search', $search );
    
    Session::put('min1', $min );
    
    Session::put('max1', $max );
    
 
    
    Session::put('notice_period', $notice_period );

  //  dd($filter_users);
  
   if(isset($location_id))
    {
            $location1 = $location_id;
    }
  
    $location2 = $request->location;
    Session::put('location1', $location2);


    return view("company.unlocked_users",compact('filter_users','min','max','location1','notice_period','search'));

} 

if($request->method() == 'GET')
{
  //  dd('get');
    $search = Session::get('search');       
    $min = Session::get('min1');
    $max = Session::get('max1');
    $location1 = Session::get('location1');
   // dd($location1);
    $notice_period = Session::get('notice_period');



    $unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->get();

    foreach($unlocked_users as $unlock)

    {

   

        $data[] = $unlock->unlocked_users_ids;

        

    }


    if($location1)
    {


        $query = User::whereIn('id', $data);
 
        if($search)
        { 
    
          $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });
    
        }
    
        if($min && $max)
        {
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }
    
      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
                
    
        }
        if($location1)
        {
        //     $query->whereHas('userlocation', function($q) use($location1){
        //         $q->whereIn('location', $location1);
        // });

        $query->whereIn('current_city', $location1);
           
        }
    
     $filter_users = $query->paginate(100);

    }else{

        $query = User::whereIn('id', $data);
 
       if($search)
       { 

           $query->whereHas('profilekeyskill', function($q) use($search,$query){
           $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

           if($key != null)
           {
           //   dd('coming');
               $q->where('keyskill', $key->id);
           } else{

               $query->whereHas('profileSummary', function($q) use($search){
               $q->where('latestdesg','like', '%' . $search . '%');
       });

           }   
           });

       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {

           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
               
       });
               
   
       }


    $filter_users = $query->paginate(100);

    }








    return view("company.unlocked_users",compact('filter_users','min','max','location1','notice_period','search'));


    
  }else{
      
      return redirect()->back();
  }




}

  
}






public function unlockedfiltersearch2(Request $request)

{

    if($request->max_exp)
    {
        $request->validate([

            'min_exp'  => 'numeric',
      
            'max_exp'  => 'numeric|gt:min_exp',
      
          ],
      [
          'max_exp.gt' => 'Max may not greater than min value'
      ]);
    }



if($request->method() == 'POST')
{

//dd($request);



$unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->get();

 //  dd($unlocked_users);

foreach($unlocked_users as $data4)
{
  $data[] = $data4->unlocked_users_ids;
//  dd($data);
}

if(count($unlocked_users) > 0)
{

    //dd($request->search);


    // $min_exp = $request->min_exp;

    // $max_exp = $request->max_exp;

        $exp = $request->min_exp;
        if($exp)
        {
            $min_exp = (int)$exp;
        }else{
            $min_exp = '';
        }
        
        $exp1 = $request->max_exp;
          if($exp)
        {
           $max_exp = (int)$exp1;
        }else{
            $max_exp = '';
        }

    $interview = $request->interview_avail;

    $education = $request->education;

    $gender = $request->gender;

    $job_type = $request->job_type;

    $course = $request->course;

    $specilation = $request->specilation;

    $collection_id1 = $request->collection_id;

    $filter_resume = $request->filter_resume;
    
    $s_date = $request->previous_start_date;
        $e_date = $request->previous_end_date;
        if($request->previous_start_date)
        {
            $startDate = date("Y-m-d", strtotime($request->previous_start_date));
        }else{
            $startDate = '';
        }
        if($request->previous_end_date)
        {
            $endDate = date("Y-m-d", strtotime($request->previous_end_date));
        }else{
            $endDate = '';
        }


    $now = \Carbon\Carbon::now();

     $today = \Carbon\Carbon::now()->format('Y-m-d');

    $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');



    $query = User::whereIn('id', $data);



//dd($query);


if($min_exp && $max_exp)
{
$query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

$q->whereBetween('totalexp', [$min_exp,$max_exp]);

});
}

        if($education)
    {
        $query->whereHas('profileEducation', function($q) use($education){
        $q->where('degree_title', $education);
    });
    }
    if($course)
    {
        $query->whereHas('profileEducation', function($q) use($course){
        $q->where('course', $course);
    });
    }

    if($specilation)
    {
        $query->whereHas('profileEducation', function($q) use($specilation){
        $q->where('specilation', $specilation);
    });
    }
    if($job_type)
    {
        $query->whereHas('profileDetails', function($q) use($job_type){
            $q->where('work_type', $job_type);
    });
    }

    if($gender)
    {
        $query->where('gender_id', $gender);
    }



     if($startDate)
              {
                 //dd($startDate);
       
                 // dd($today);
                  $query->whereHas('interViews', function($q) use($startDate,$endDate){
                      $q->whereBetween('date', [$startDate, $endDate]);
                 // dd($q);
              });
              
                 
              }


    
            if($filter_resume == '1')
            {

                $query->where('verified', 1);


            }
            if($filter_resume == '2')
            {
                $query->where('verified', 0);
            }
            if($filter_resume == '3')
            {
            
            
                    $query->where('package_end_date','>',$now);

            }


$filter_users = $query->paginate(100);

  



//dd($filter2_users);
Session::put('min_exp', $min_exp );
   
//  Session::put('min1', $min );
  
  Session::put('max_exp', $max_exp );
  
  Session::put('interview_avail', $interview );
  
  Session::put('education', $education );

  Session::put('course', $course );
  
  Session::put('specilation', $specilation );
  
  Session::put('gender', $gender );

  Session::put('job_type', $job_type );

  Session::put('collection_id1', $collection_id1 );

  Session::put('filter_resume', $filter_resume );
  
  
  Session::put('startDate', $startDate );
        
        Session::put('endDate', $endDate );




return view("company.unlocked_users",compact('filter_users','min_exp','max_exp','interview','education','course','specilation','job_type','gender','filter_resume','s_date','e_date'));



}


if($request->method() == 'GET')
{


    $unlocked_users = Unlocked_users::where('company_id', Auth::guard('company')->user()->id)->get();



foreach($unlocked_users as $data4)
{
  $data[] = $data4->unlocked_users_ids;
//    dd($data);
}


$min_exp = Session::get('min_exp');
$max_exp = Session::get('max_exp');
$interview = Session::get('interview_avail');
$education = Session::get('education');
$course = Session::get('course');
$specilation = Session::get('specilation');
$gender = Session::get('gender');
$job_type = Session::get('job_type');
$filter_resume = Session::get('filter_resume');
  $startDate = Session::get('startDate');
        $endDate = Session::get('endDate');





  $now = \Carbon\Carbon::now();

  $today = \Carbon\Carbon::now()->format('Y-m-d');

  $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');



   
  $query = User::whereIn('id', $data);
    
    

  //dd($query);


  if($min_exp && $max_exp)
  {
  $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

  $q->whereBetween('totalexp', [$min_exp,$max_exp]);
  
  });
}
  
          if($education)
      {
          $query->whereHas('profileEducation', function($q) use($education){
          $q->where('degree_title', $education);
      });
      }
      if($course)
      {
          $query->whereHas('profileEducation', function($q) use($course){
          $q->where('course', $course);
      });
      }

      if($specilation)
      {
          $query->whereHas('profileEducation', function($q) use($specilation){
          $q->where('specilation', $specilation);
      });
      }
      if($job_type)
      {
          $query->whereHas('profileDetails', function($q) use($job_type){
              $q->where('work_type', $job_type);
      });
      }

      if($gender)
      {
          $query->where('gender_id', $gender);
      }


  if($startDate)
              {
                 //dd($startDate);
       
                 // dd($today);
                  $query->whereHas('interViews', function($q) use($startDate,$endDate){
                      $q->whereBetween('date', [$startDate, $endDate]);
                 // dd($q);
              });
              
                 
              }


      if($filter_resume == '1')
      {

          $query->where('verified', 1);

    
      }
      if($filter_resume == '2')
      {
          $query->where('verified', 0);
      }

      if($filter_resume == '3')
      {
         
        
              $query->where('package_end_date','>',$now);
     
      }


  
  $filter_users = $query->paginate(100);



    Session::put('min_exp', $min_exp );
       
    //  Session::put('min1', $min );
      




return view("company.unlocked_users",compact('filter_users','min_exp','max_exp','interview','education','job_type','gender','s_date','e_date'));
    
}else{
    return redirect()->back();
}


}


}



/************************************************    Bulk Email  ***************************************** */





public function search2(Request $request)

{


$search = $request->search;



$collections = CollectionList::where('collection_id','=',$request->collection_id)->get();

   

foreach($collections as $unlock)

{



    $data[] = $unlock->user_id;

    

}



  $search_users = User::whereHas('profileSummary', function($q) use($search){

            $q->where('latestdesg', $search);

        })->whereIn('id', $data)->get();


        return view("collectionsbulkmail",compact('search_users','collections'));



}


public function bulkfiltersearch1(Request $request)

{

    if($request->max_salary)
    {
        $request->validate([

            'min_salary'  => 'numeric',
      
            'max_salary'  => 'numeric|gt:min_salary',
      
          ],
      [
          'max_salary.gt' => 'Max may not greater than min value'
      ]);
    }



if($request->method() == 'POST')
{
   //dd($request->all());

   $collections = CollectionList::where('collection_id','=',$request->collection_id)->get();


   $folder_id = $request->collection_id;

foreach($collections as $unlock)

{



    $data[] = $unlock->user_id;

    

}

    $search = $request->search;

    $bulk12 = $request->min_salary;

    $bulk13 = $request->max_salary;

    $min = (int)$bulk12;   
    $max = (int)$bulk13;
    

    $collection_id = $request->collection_id;

    // $location1 = $request->location;

    // $notice_period = $request->notice_period;

    if($request->location)
    {
        $location1 = $request->location;
    }
    else
    {
         $location1 =NULL;
    }
    if($request->notice_period)
    {
       $notice_period = $request->notice_period;
    }
    else
    {
            $notice_period =NULL;
    }


if($location1)
{
    $query = User::whereIn('id', $data);
 
    if($search)
    { 

       $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min && $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
     if($location1)
    {
        foreach($location1 as $location)
                {
               // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });
       
    }

 $filter_users = $query->paginate(100);

   }else{
       
    $query = User::whereIn('id', $data);
 
       if($search)
       { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {
           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
       });
               
   
       }


    $filter_users = $query->paginate(100);

   }


    


// dd($filter1_users);


// Session::put('filter1_users', $filter1_users );// $this->filter2search($filter1_users);

Session::put('search', $search );

Session::put('min1', $min );

Session::put('max1', $max );



Session::put('notice_period', $notice_period );

Session::put('collection_id', $collection_id );

    if(isset($location_id))
    {
            $location1 = $location_id;
    }
  
    $location2 = $request->location;
    Session::put('location1', $location2);




    return view("collectionsbulkmail",compact('filter_users','collections','search','min','max','location1','notice_period','folder_id'));
    
}
if($request->method() == 'GET')
{
  //  dd('get');



  $collection_id = Session::get('collection_id');

  $folder_id = $collection_id;


    $collections = CollectionList::where('collection_id','=',$collection_id)->get();

         // dd($collections);
    
    foreach($collections as $unlock)
    
    {
    
    
    
        $data[] = $unlock->user_id;
    
        
    
    }
        
 
    
   $search = Session::get('search');
    
   
   $min = Session::get('min1');
//    return dd($min);
    
   $max =Session::get('max1');
  
    
   $location1 =Session::get('location1');
    
   $notice_period = Session::get('notice_period');

    
   if($location1)
   {
     $query = User::whereIn('id', $data);
 
    if($search)
    { 

       $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min && $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
   if($location1)
    {
        foreach($location1 as $location)
                {
               // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });
       
    }

 $filter_users = $query->paginate(100);

}else{
   $query = User::whereIn('id', $data);
 
       if($search)
       { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {
           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
       });
               
   
       }


    $filter_users = $query->paginate(100);

}
    
    
  if(isset($location_id))
    {
            $location1 = $location_id;
    }


    
    
    // dd($filter_users);
    
    return view("collectionsbulkmail",compact('filter_users','collections','search','min','max','location1','notice_period','folder_id'));
    
        // return view("collectionsbulkmail",compact('filter1_users','collections','search','min','max','location1','notice_period'));
}


}



public function bulkfiltersearch2(Request $request)

    {
      //  return dd($request);

      if($request->max_exp)
      {
          $request->validate([
  
              'min_exp'  => 'numeric',
        
              'max_exp'  => 'numeric|gt:min_exp',
        
            ],
        [
            'max_exp.gt' => 'Max may not greater than min value'
        ]);
      }


if($request->method() == 'POST')
{

  

      $collections = CollectionList::where('collection_id','=',$request->collection_id)->get();

      $folder_id = $request->collection_id;


// dd($collections);


      foreach($collections as $unlock)

      {

     

          $data[] = $unlock->user_id;

          

      }

      

     // dd($data);

        //dd('heelo');

      

        // $min_exp = $request->min_exp;

        // $max_exp = $request->max_exp;

        $exp = $request->min_exp;
        if($exp)
        {
            $min_exp = (int)$exp;
        }else{
            $min_exp = '';
        }
        
        $exp1 = $request->max_exp;
          if($exp)
        {
           $max_exp = (int)$exp1;
        }else{
            $max_exp = '';
        }

        $interview = $request->interview_avail;

        $education = $request->education;

        $gender = $request->gender;

        //return dd($gender);

        $job_type = $request->job_type;

        $course = $request->course;

        $specilation = $request->specilation;

        $collection_id1 = $request->collection_id;

        $filter_resume = $request->filter_resume;
        
        $s_date = $request->previous_start_date;
        $e_date = $request->previous_end_date;
        if($request->previous_start_date)
        {
            $startDate = date("Y-m-d", strtotime($request->previous_start_date));
        }else{
            $startDate = '';
        }
        if($request->previous_end_date)
        {
            $endDate = date("Y-m-d", strtotime($request->previous_end_date));
        }else{
            $endDate = '';
        }


      
        $now = \Carbon\Carbon::now();

      

         $today = \Carbon\Carbon::now()->format('Y-m-d');

  $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');


   
    $query = User::whereIn('id', $data);
    
    

    //dd($query);


    if($min_exp && $max_exp)
    {
    $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

    $q->whereBetween('totalexp', [$min_exp,$max_exp]);
    
    });
}
    
            if($education)
        {
            $query->whereHas('profileEducation', function($q) use($education){
            $q->where('degree_title', $education);
        });
        }
        if($course)
        {
            $query->whereHas('profileEducation', function($q) use($course){
            $q->where('course', $course);
        });
        }

        if($specilation)
        {
            $query->whereHas('profileEducation', function($q) use($specilation){
            $q->where('specilation', $specilation);
        });
        }
        if($job_type)
        {
            $query->whereHas('profileDetails', function($q) use($job_type){
                $q->where('work_type', $job_type);
        });
        }

        if($gender)
        {
            $query->where('gender_id', $gender);
        }



        if($startDate)
              {
                 //dd($startDate);
       
                 // dd($today);
                  $query->whereHas('interViews', function($q) use($startDate,$endDate){
                      $q->whereBetween('date', [$startDate, $endDate]);
                 // dd($q);
              });
              
                 
              }

        if($filter_resume == '1')
        {

            $query->where('verified', 1);

      
        }
        if($filter_resume == '2')
        {
            $query->where('verified', 0);
        }
        if($filter_resume == '3')
        {
           
          
                $query->where('package_end_date','>',$now);
       
        }

    
    $filter_users = $query->paginate(100);

      

    

    //dd($filter2_users);
    Session::put('min_exp', $min_exp );
       
    //  Session::put('min1', $min );
      
      Session::put('max_exp', $max_exp );
      
      Session::put('interview_avail', $interview );
      
      Session::put('education', $education );

      Session::put('course', $course );
      
      Session::put('specilation', $specilation );
      
      Session::put('gender', $gender );

      Session::put('job_type', $job_type );

      Session::put('collection_id1', $collection_id1 );

      Session::put('filter_resume', $filter_resume );
      
        Session::put('startDate', $startDate );
        
        Session::put('endDate', $endDate );



    return view("collectionsbulkmail",compact('filter_users','collections','min_exp','max_exp','interview','gender','education','job_type','course','specilation','folder_id','filter_resume','s_date','e_date'));
}


if($request->method() == 'GET')
{



    $collection_id1  = Session::get('collection_id1');
    $folder_id = $collection_id1;
    $collections = CollectionList::where('collection_id','=',$collection_id1)->get();





    foreach($collections as $unlock)

    {

   

        $data[] = $unlock->user_id;

        

    }

    

   // dd($data);

      //dd('heelo');

    

      $min_exp = Session::get('min_exp');
      $max_exp = Session::get('max_exp');
      $interview = Session::get('interview_avail');
      $education = Session::get('education');
      $course = Session::get('course');
      $specilation = Session::get('specilation');
      $gender = Session::get('gender');
      $job_type = Session::get('job_type');
      $filter_resume = Session::get('filter_resume');
        $startDate = Session::get('startDate');
        $endDate = Session::get('endDate');

    


      $now = \Carbon\Carbon::now();
       $today = \Carbon\Carbon::now()->format('Y-m-d');

$tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');


 
  $query = User::whereIn('id', $data);
  
  

  //dd($query);


  if($min_exp && $max_exp)
  {
  $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

  $q->whereBetween('totalexp', [$min_exp,$max_exp]);
  
  });
}
  
          if($education)
      {
          $query->whereHas('profileEducation', function($q) use($education){
          $q->where('degree_title', $education);
      });
      }
      if($course)
      {
          $query->whereHas('profileEducation', function($q) use($course){
          $q->where('course', $course);
      });
      }

      if($specilation)
      {
          $query->whereHas('profileEducation', function($q) use($specilation){
          $q->where('specilation', $specilation);
      });
      }
      if($job_type)
      {
          $query->whereHas('profileDetails', function($q) use($job_type){
              $q->where('work_type', $job_type);
      });
      }

      if($gender)
      {
          $query->where('gender_id', $gender);
      }



      if($startDate)
      {
         //dd($startDate);

         // dd($today);
          $query->whereHas('interViews', function($q) use($startDate,$endDate){
              $q->whereBetween('date', [$startDate, $endDate]);
         // dd($q);
      });
      
         
      }


      if($filter_resume == '1')
      {

          $query->where('verified', 1);

    
      }
      if($filter_resume == '2')
      {
          $query->where('verified', 0);
      }

      if($filter_resume == '3')
      {
         
        
              $query->where('package_end_date','>',$now);
     
      }


  
  $filter_users = $query->paginate(100);

  //dd($filter2_users);


  return view("collectionsbulkmail",compact('filter_users','collections','min_exp','max_exp','interview','gender','education','job_type','course','specilation','folder_id','filter_resume','s_date','e_date'));





}
    

    

    

    }







    public function changeCompanyPassword()

    {

        $company = Company::findOrFail(Auth::guard('company')->user()->id);

        // return dd($company);

        return view('company_auth.passwords.change_com_password',compact('company'));

    }



    public function updateCompanyPassword(Request $request,$id)

    {



        // $user = User::findOrFail(Auth::user()->id);



        // $request->validate([

        //     'old_password'=>'required',

        //     'new_password'=>'required|min:6',

        //     'new_password_confirmation'=>'required|same:new_password|min:6'

        // ]);
        $this->validate(

            $request, 
            [
                'old_password'=>'required',
        
                'new_password' =>'required|min:6|max:12',
            
                'new_password_confirmation'  => 'required|same:new_password|min:6|max:12'
            ],
            [
        
                'old_password.required' => ' Old Password is required',
                'new_password.required' => ' New Password is required',
                'new_password_confirmation.required' => ' Confirm New Password is required',
               
            ]
        );


        $hashedPassword = Auth::guard('company')->user()->password;

        // dd($hashedPassword);



        if (\Hash::check($request->old_password , $hashedPassword )) {



            if (!\Hash::check($request->new_password , $hashedPassword))

            {

                $company =Auth::guard('company')->user()->get();

                // dd($company);

                $company->password = bcrypt($request->new_password);

                Company::where( 'id' , Auth::guard('company')->user()->id)->update( array( 'password' => $company->password));

                

                // session()->flash('message','Password updated successfully');

                // return back()->with('success', 'Password updated successfully!');

                return redirect()->back()->with('message', 'Password updated successfully');

            }



            else{

                return redirect()->back()->with('message', "New password can not be the old password");

            }

        }

        else{

            return redirect()->back()->with('error', "Old password doesn't matched");

        }

    }



    // Add resumes to Folder

    public function addResumes(Request $request)

    {



        $collection_list = CollectionList::where('collection_id',$request->collection_id)->get();

      

        if(count($collection_list) < 100)
        {
       //return dd('value');

      // return dd(count($collection_list));

        $this->validate(

            $request, 
            [
               
            'collection_id'  => 'required',

               
            ],
            [
        
               'collection_id.required'  => 'Folder is required'
               
            ]
        );


        $company_id =Auth::guard('company')->user()->id;
        // dd($company_id);

        $collection_list = CollectionList::where('user_id',$request->user_id)->where('collection_id',$request->collection_id)->first();

        // dd($collection_list);

        if (empty($collection_list)) {

            $collection_folder_list = new CollectionList;

            $collection_folder_list->user_id=$request->user_id;

            $collection_folder_list->company_id=$company_id;

            $collection_folder_list->collection_id=$request->collection_id;

            $collection_folder_list->save();


            // return dd($collection_folder_list);

            return response()->json(array('success' => true, 'status' => 200), 200);
           // return back()->with('message','Resume added successfully');

        } else {
            // return response()->json(array('success' => true, 'status' => 200), 200);
            return response()->json(array('error' => true, 'status' => 400), 400);
         //   $msgresponse = ['error' => 'erroe', 'message' => __('Message sent successfully')];

         //   echo json_encode($msgresponse);

          //  return response()->json(array('errors' => true, 'status' => 422), 422); 

          //  return back()->with('error','Resume already exists in this collection');

        }

            
    }else{
       // return dd('no value');
        return response()->json(array('error1' => true, 'status' => 402), 402);
    }

        

        

    }

    public function addBulkResumes(Request $request)

    {

       // dd($request->all());


        $collection_list = CollectionList::where('collection_id',$request->collection_id)->get();

      //dd(count($collection_list));

        if(count($collection_list) < 100)
        {
       //return dd($request->all());

      // return dd(count($collection_list));

        $this->validate(

            $request, 
            [
               
            'collection_id'  => 'required',
            'user_id1'  => 'required'

               
            ],
            [
                'user_id1.required'  => 'Note : Select atleast one user',
        
               'collection_id.required'  => 'Folder is required'
               
            ],
        );


        $company_id =Auth::guard('company')->user()->id;
        // dd($company_id);

        $user_idsec = $request->user_id1;

        //dd($user_ids1)
        $user_ids= (explode(",",$user_idsec));
   

        foreach($user_ids as $user_id)
        {
            $collection_list = CollectionList::where('user_id',$user_id)->where('collection_id',$request->collection_id)->first();
          
             if (empty($collection_list)) {

                $collection_folder_list = new CollectionList;
    
                $collection_folder_list->user_id=$user_id;
    
                $collection_folder_list->company_id=$company_id;
    
                $collection_folder_list->collection_id=$request->collection_id;
    
                $collection_folder_list->save();
    
    
                // return dd($collection_folder_list);
    
               
               // return back()->with('message','Resume added successfully');
    
             }
           
       
        }

        return response()->json(array('success' => true, 'status' => 200), 200);
       
            
    }else{
       // return dd('no value');
        return response()->json(array('error1' => true, 'status' => 402), 402);
    }

        

        

    }

    public function updatefrontcompany(Request $request)
    {
       // dd($request);

        $company = Company::where('id',$request->company_id)->first();

        $company->name = $request->name;
        $company->email = $request->email;
        $company->phone = $request->phone;
        $company->ceo = $request->ceo;
        $company->save();
        
        return response()->json(['success','Updated Successfully']);
    }



public function ajax11(Request $request)
{
  //  dd('helooo');
    $user = User::paginate(3);
 
    if ($request->ajax()) {
        $view = view('company.candidate_listing',compact('user'))->render();
        return response()->json(['html'=>$view]);
    }

    return view('candidate_listing',compact('user'));
}
public function paymenthistory()
{
    $company_id =Auth::guard('company')->user()->id;

    $company_detail = Company::where('id',$company_id)->first();

    $payments = EmployerPayment::where('company_id',$company_id)->latest()->get();

    return view('company.payment-history',compact('payments','company_detail'));

}


public function updateprofilesection()
{
    return view('company.updateprofile');
}




public function  imagestore(Request $request)
{

        
$company_id = Auth::guard('company')->user()->id;
$company = Company::where('id',$company_id)->first();



if ($request->hasFile('logo')) {
    $is_deleted = $this->deleteCompanyLogo($company->id);
    $image = $request->file('logo');
    $fileName = ImgUploader::UploadImage('company_logos', $image, 300, 300, false);
    $company->logo = $fileName;

}
$company->save();

return response()->json(['success','Updated Successfully']);

}

public function draft()
{
    $drafts = Draft::where('emailed',0)->where('company_id',Auth::guard('company')->user()->id)->get();
    $draft_value = Draft::where('emailed',0)->where('company_id',Auth::guard('company')->user()->id)->first();
    
    return view('company.draft',compact('drafts','draft_value'));
}


public function storedraft(Request $request)
{
   
  $request->validate([
           
            'name' => 'required',
            'message' => 'required',

        ],[
        
            'name.required'  => 'Name is required',

            'message.required'  => 'Message is required'
        ]);
   
        $draft = new Template();     
        $draft->company_id = Auth::guard('company')->user()->id;
        $draft->name = $request->name;
        $draft->message = $request->message;      
        $draft->save();
 
        return response()->json(array('success' => true, 'status' => 200), 200);

   

}

public function bulksms(Request $request)
{
  
    $request->validate([

        'message' => 'required',
        'user_id' => 'required'

    ],
    [
        'message.required' => 'Message is required',
        'user_id.required' => 'Note : Select atleast one user',
    ]

);
      $emails = $request->user_id;
            $email= (explode(",",$emails));

            if (isset($email)) {

                $users = User::whereIn('id',$email)->get();
                //return dd($users);

                foreach ($users as $user_mail) {
               
                    $apiKey = urlencode('MzA2MzUwMzA1NTc1NDU3MjZmMzk3MTQ5NTA3OTUzNDk=	');
	
                    // Message details
                    $numbers = array(916374363023, 917639069608);
                    $sender = urlencode('600010');
                    $otp = 1230;
                        $message = rawurlencode('Hi there, thank you for sending your first test message from Textlocal. Get 20% off today with our code: '.$otp.'.');

                    $numbers = implode(',', $numbers);

                    // Prepare data for POST request
                    $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);

                    // Send the POST request with cURL
                    $ch = curl_init('https://api.textlocal.in/send/');
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $response = curl_exec($ch);
                    curl_close($ch);

                } 


                return response()->json(array('success' => true, 'status' => 200), 200);
            }
}

// Draft Filter

public function draftfiltersearch1(Request $request)

{

    $request->validate([



    ]);



if($request->method() == 'POST')
{
   

  //  dd($request->all());

    $company_id = Auth::guard('company')->user()->id;

    $collections = Draft::where('company_id','=',$company_id)->get();

    if(count($collections) > 0)
    {

  

    foreach($collections as $draft)
    
    {
    
    
    
        $data[] = $draft->user_id;
    
        
    
    }
  

    $search = $request->search;

    $bulk12 = $request->min_salary;

    $bulk13 = $request->max_salary;

    $min = (int)$bulk12;   
    $max = (int)$bulk13;
    

    if($request->location)
    {
        $location1 = $request->location;
    }
    else
    {
         $location1 =NULL;
    }
    if($request->notice_period)
    {
       $notice_period = $request->notice_period;
    }
    else
    {
            $notice_period =NULL;
    }


    if($location1)
    {
        $query = User::whereIn('id', $data);
 
        if($search)
        { 
    
          $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });
    
        }
    
        if($min && $max)
        {
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }
    
      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
                
    
        }
           if($location1)
    {
        foreach($location1 as $location)
                {
               // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });
       
    }
    
     $filter_users = $query->paginate(100);

   }else{
       

       $query = User::whereIn('id', $data);
 
       if($search)
       { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });
       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {
           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
       });
               
   
       }


    $filter_users = $query->paginate(100);

   }






// dd($filter1_users);


// Session::put('filter1_users', $filter1_users );// $this->filter2search($filter1_users);

Session::put('search', $search );

Session::put('min1', $min );

Session::put('max1', $max );



Session::put('notice_period', $notice_period );

if(isset($location_id))
    {
            $location1 = $location_id;
    }
  
    $location2 = $request->location;
    Session::put('location1', $location2);


    return view("company.draft",compact('filter_users','collections','search','min','max','location1','notice_period'));

      }else{

        return redirect()->back();

      }
    
}
if($request->method() == 'GET')
{
  //  dd('get');



    $company_id = Auth::guard('company')->user()->id;

    $collections = Draft::where('company_id','=',$company_id)->get();


    
    foreach($collections as $draft)
    
    {
    
    
    
        $data[] = $draft->user_id;
    
        
    
    } 
 
    
   $search = Session::get('search');
    
   
   $min = Session::get('min1');
//    return dd($min);
    
   $max =Session::get('max1');
  
    
   $location1 =Session::get('location1');
    
   $notice_period = Session::get('notice_period');

    
   if($location1)
   {
    $query = User::whereIn('id', $data);
 
    if($search)
    { 

      $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min && $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
        if($location1)
    {
        foreach($location1 as $location)
                {
               // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });
       
    }

 $filter_users = $query->paginate(100);

}else{
    $query = User::whereIn('id', $data);
 
       if($search)
       { 

           $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

       }
   
       if($min && $max)
       {
   
           $query->whereHas('profileDetails', function($q) use($min,$max){
               $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
       });
   
       }

     
       if($notice_period)
       {
           $query->whereHas('profileNop', function($q) use($notice_period,$location1){
               $q->whereIn('nop_days', $notice_period);
       });
               
   
       }


    $filter_users = $query->paginate(100);

}
    
    
  if(isset($location_id))
    {
            $location1 = $location_id;
    }

    
    
    // dd($filter1_users);
    
    return view("company.draft",compact('filter_users','collections','search','min','max','location1','notice_period'));
    
        // return view("collectionsbulkmail",compact('filter1_users','collections','search','min','max','location1','notice_period'));
}


}

public function draftsubfiltersearch(Request $request)

    {
      

if($request->method() == 'POST')
{

    $company_id = Auth::guard('company')->user()->id;

    $collections = Draft::where('company_id','=',$company_id)->get();

    if(count($collections) > 0)
    {

    foreach($collections as $draft)
    
    {
    
    
    
        $data[] = $draft->user_id;
    
        
    
    } 


        $exp = $request->min_exp;
        $min_exp = (int)$exp;
        $exp1 = $request->max_exp;
        $max_exp = (int)$exp1;

        $interview = $request->interview_avail;

        $education = $request->education;

        $gender = $request->gender;

        //return dd($gender);

        $job_type = $request->job_type;

        $course = $request->course;

        $specilation = $request->specilation;

        $filter_resume = $request->filter_resume;

      
        $now = \Carbon\Carbon::now();

         $today = \Carbon\Carbon::now()->format('Y-m-d');

         $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');


   
    $query = User::whereIn('id', $data);
    
    

    //dd($query);


    if($min_exp && $max_exp)
    {
    $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

    $q->whereBetween('totalexp', [$min_exp,$max_exp]);
    
    });
}
    
            if($education)
        {
            $query->whereHas('profileEducation', function($q) use($education){
            $q->where('degree_title', $education);
        });
        }
        if($course)
        {
            $query->whereHas('profileEducation', function($q) use($course){
            $q->where('course', $course);
        });
        }

        if($specilation)
        {
            $query->whereHas('profileEducation', function($q) use($specilation){
            $q->where('specilation', $specilation);
        });
        }
        if($job_type)
        {
            $query->whereHas('profileDetails', function($q) use($job_type){
                $q->where('work_type', $job_type);
        });
        }

        if($gender)
        {
            $query->where('gender_id', $gender);
        }



        if($interview == '1')
        {
         //  dd($today);
 
           // dd($today);
            $query->whereHas('profileDetails', function($q) use($today){
                $q->where('video_date_from', '<=',$today)->where('video_date_to', '>=', $today)->where('night_telephonic_date_from', '<=',$today)->where('night_telephonic_date_to', '>=', $today);
           // dd($q);
        });
        
           
        }
        elseif($interview == '2'){
           // dd('tommorrow');
        
               // dd($today);
                $query->whereHas('profileDetails', function($q) use($tommorrow){
                    $q->where('video_date_from', '<=',$tommorrow)->where('video_date_to', '>=', $tommorrow)->where('night_telephonic_date_from', '<=',$tommorrow)->where('night_telephonic_date_to', '>=', $tommorrow);
               // dd($q);
            });
            
        }

        if($filter_resume == '1')
        {

            $query->where('verified', 1);

      
        }
        if($filter_resume == '2')
        {
            $query->where('verified', 0);
        }
        if($filter_resume == '3')
        {
           
          
                $query->where('package_end_date','>',$now);
       
        }

    
    $filter_users = $query->paginate(100);

      

    

    //dd($filter2_users);
    Session::put('min_exp', $min_exp );
       
    //  Session::put('min1', $min );
      
      Session::put('max_exp', $max_exp );
      
      Session::put('interview_avail', $interview );
      
      Session::put('education', $education );

      Session::put('course', $course );
      
      Session::put('specilation', $specilation );
      
      Session::put('gender', $gender );

      Session::put('job_type', $job_type );

      Session::put('filter_resume', $filter_resume );

    return view("company.draft",compact('filter_users','collections','min_exp','max_exp','interview','gender','education','job_type','course','specilation','filter_resume'));


    }else{

        return redirect()->back();
    }


    
}


if($request->method() == 'GET')
{



    $company_id = Auth::guard('company')->user()->id;

    $collections = Draft::where('company_id','=',$company_id)->get();


    
    foreach($collections as $draft)
    
    {
    
    
    
        $data[] = $draft->user_id;
    
        
    
    } 


      $min_exp = Session::get('min_exp');
      $max_exp = Session::get('max_exp');
      $interview = Session::get('interview_avail');
      $education = Session::get('education');
      $course = Session::get('course');
      $specilation = Session::get('specilation');
      $gender = Session::get('gender');
      $job_type = Session::get('job_type');
      $filter_resume = Session::get('filter_resume');
     
    
      $now = \Carbon\Carbon::now();

       $today = \Carbon\Carbon::now()->format('Y-m-d');

       $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');


 
  $query = User::whereIn('id', $data);
  
  

  //dd($query);


  if($min_exp && $max_exp)
  {
  $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){

  $q->whereBetween('totalexp', [$min_exp,$max_exp]);
  
  });
}
  
          if($education)
      {
          $query->whereHas('profileEducation', function($q) use($education){
          $q->where('degree_title', $education);
      });
      }
      if($course)
      {
          $query->whereHas('profileEducation', function($q) use($course){
          $q->where('course', $course);
      });
      }

      if($specilation)
      {
          $query->whereHas('profileEducation', function($q) use($specilation){
          $q->where('specilation', $specilation);
      });
      }
      if($job_type)
      {
          $query->whereHas('profileDetails', function($q) use($job_type){
              $q->where('work_type', $job_type);
      });
      }

      if($gender)
      {
          $query->where('gender_id', $gender);
      }



      if($interview == '1')
      {
       //  dd($today);

         // dd($today);
          $query->whereHas('profileDetails', function($q) use($today){
              $q->where('video_date_from', '<=',$today)->where('video_date_to', '>=', $today)->where('night_telephonic_date_from', '<=',$today)->where('night_telephonic_date_to', '>=', $today);
         // dd($q);
      });
      
         
      }
      elseif($interview == '2'){
         // dd('tommorrow');
      
             // dd($today);
              $query->whereHas('profileDetails', function($q) use($tommorrow){
                  $q->where('video_date_from', '<=',$tommorrow)->where('video_date_to', '>=', $tommorrow)->where('night_telephonic_date_from', '<=',$tommorrow)->where('night_telephonic_date_to', '>=', $tommorrow);
             // dd($q);
          });
          
      }


      
      if($filter_resume == '1')
      {

          $query->where('verified', 1);

    
      }
      if($filter_resume == '2')
      {
          $query->where('verified', 0);
      }

      if($filter_resume == '3')
      {
         
        
              $query->where('package_end_date','>',$now);
     
      }

  
  $filter_users = $query->paginate(100);

  //dd($filter2_users);


  return view("company.draft",compact('filter_users','collections','min_exp','max_exp','interview','gender','education','job_type','course','specilation','filter_resume'));

}
    
    }


    public function save_search(Request $request)
    {
     //   dd($request->all());
        $request->validate([

            'search_value' => 'required'


        ],
        [
            'search_value.required'  => 'Search name is requried'

        ]

    );

       //dd($request->all());

        $search = new SaveSearch();
        $search->company_id = Auth::guard('company')->user()->id;
        $search->search_value = $request->search_value;
        $search->search = $request->search;
        if($request ->location)
        {
             $search->location = serialize($request->location);

        }else{
             $search->location = NUll;

        }
       
        $search->notice_period = $request->notice_period;
        $search->min_salary = $request->min_salary;
        $search->max_salary = $request->max_salary;

        $search->min_exp = $request->min_exp;
        $search->max_exp = $request->max_exp;
        $search->filter_resume = $request->filter_resume;
        $search->interview_avail = $request->interview_avail;
        $search->education = $request->education;
        $search->course = $request->course;
        $search->specilation = $request->specilation;
        $search->gender = $request->gender;
        $search->job_type = $request->job_type;
         $search->filter = $request->filter;
        $search->save();

       return response()->json(['success','Saved Successfully']);
    }

    public function saved_search(Request $request)
    {
        return view('company.savedsearch');
    }

    public function delete_saved_search($id)
    {
       $search = SaveSearch::where('id',$id)->delete();

       return redirect()->back()->with('message','Successfully Deleted');
    }

    public function searchnow($id)
    {
       $search_value = SaveSearch::where("id",$id)->first();


       if($search_value->filter == 1)
       {

       
        $search = $search_value->search;
        $new = $search_value->min_salary;
        $min = (int)$new;
        $new1 = $search_value->max_salary;
        $max = (int)$new1;      
        if($search_value->location)
        {
            $location1 = unserialize($search_value->location);
        }
        else
        {
             $location1 =NULL;
        }
        if($search_value->notice_period)
        {
           $notice = $search_value->notice_period;
           $notice_period = explode(",",$notice);
        }
        else
        {
                $notice_period =NULL;
        }




    if($location1)
    {
       $query = User::latest();
 
    if($search)
    { 

         $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

    }

    if($min && $max)
    {

        $query->whereHas('profileDetails', function($q) use($min,$max){
            $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
    });

    }

  
    if($notice_period)
    {
        $query->whereHas('profileNop', function($q) use($notice_period,$location1){
            $q->whereIn('nop_days', $notice_period);
    });
            

    }
    if($location1)
    {
        foreach($location1 as $location)
                {
               // dd($location);
                $location_val = Location::where('location','like',"%{$location}%")->first();
               
                  $location_id[] = $location_val->id;
                }
        $query->whereHas('userlocation', function($q) use($location1){
            $q->whereIn('location', $location1);
    });
       
    }

 $filter_users = $query->paginate(100);
       
   }else{


     $query = User::latest();
 
        if($search)
        { 

            $query->where(function($q) use($search,$query){

            $q->whereHas('profilekeyskill', function($q) use($search,$query){

            $key = JobSkill::where('job_skill','like', '%' . $search . '%')->first();

            if($key != null)
                    {
                    
                        $q->where('keyskill', $key->id);


                    }else{

                        $query->WhereHas('profileSummary', function($q) use($search){

                $q->where('latestdesg','like', '%' . $search . '%');


                  });

                            }

                     })->orWhereHas('profileSummary', function($q) use($search){

                        $q->where('latestdesg','like', '%' . $search . '%');


                });
                     });

        }
       




    
        if($min && $max)
        {
    
            $query->whereHas('profileDetails', function($q) use($min,$max){
                $q->whereBetween('expect_ctc_lakhs3', [$min,$max]);
        });
    
        }

      
        if($notice_period)
        {
            $query->whereHas('profileNop', function($q) use($notice_period,$location1){
                $q->whereIn('nop_days', $notice_period);
        });
                
    
        }


     $filter_users = $query->paginate(100);

   }

   // dd($filter_users);

   
    
    Session::put('filter_users', $filter_users );// $this->filter2search($filter1_users);
    
     $search1 = Session::put('search', $search );
        //return dd($search1);
    
    Session::put('min1', $min );
    
    Session::put('max1', $max );
    
  
    
    Session::put('notice_period', $notice_period );


    $filter = 1;

    if($min)
    {
        
    }else{
       $min = '';
       $max = '';
    }
    
        if(isset($location_id))
    {
            $location1 = $location_id;
    }
  
    $location2 = unserialize($search_value->location);
    Session::put('location1', $location2);
    
    return view("company.candidate_listing",compact('filter_users','search1','min','max','location1','notice_period','filter'));

      


       
    }else{

        $exp = $search_value->min_exp;
        $min_exp = (int)$exp;
        $exp1 = $search_value->max_exp;
        $max_exp = (int)$exp1;
        $interview = $search_value->interview_avail;
        $education = $search_value->education;
        $course = $search_value->course;
        $specilation = $search_value->specilation;
        $gender = $search_value->gender;
        $job_type = $search_value->job_type;
        $filter_resume = $search_value->filter_resume;

        $now = \Carbon\Carbon::now();

       // dd($now);

        $today = \Carbon\Carbon::now()->format('Y-m-d');      
        $tommorrow = \Carbon\Carbon::now()->addDay(1)->format('Y-m-d');
      
      
     // $use = User::where('package_end_date','>',$now)->where('complete','>=',13)->get()->dd();
         
          $query = User::latest();
          
          if($min_exp && $max_exp)
          {
              $query->whereHas('profileSummary', function($q) use($min_exp,$max_exp){
      
              $q->whereBetween('totalexp', [$min_exp,$max_exp]);
          
            });
          }
          
          if($education)
          {
                $query->whereHas('profileEducation', function($q) use($education){
                
                $q->where('degree_title', $education);
              
            });
          }
      
          if($course)
          {
                
               $query->whereHas('profileEducation', function($q) use($course){
               
               $q->where('course', $course);
             
             });
          }
      
              if($specilation)
              {
                  $query->whereHas('profileEducation', function($q) use($specilation){
                  $q->where('specilation', $specilation);
              });
              }
      
              if($job_type)
              {
                  $query->whereHas('profileDetails', function($q) use($job_type){
                      $q->where('work_type', $job_type);
              });
              }
      
              if($gender)
              {
                  $query->where('gender_id', $gender);
              }
      
      
      
              if($interview == '1')
              {
               //  dd($today);
       
                 // dd($today);
                  $query->whereHas('profileDetails', function($q) use($today){
                      $q->where('video_date_from', '<=',$today)->where('video_date_to', '>=', $today)->where('night_telephonic_date_from', '<=',$today)->where('night_telephonic_date_to', '>=', $today);
                 // dd($q);
              });
              
                 
              }
              elseif($interview == '2'){
                 // dd('tommorrow');
              
                     // dd($today);
                      $query->whereHas('profileDetails', function($q) use($tommorrow){
                          $q->where('video_date_from', '<=',$tommorrow)->where('video_date_to', '>=', $tommorrow)->where('night_telephonic_date_from', '<=',$tommorrow)->where('night_telephonic_date_to', '>=', $tommorrow);
                     // dd($q);
                  });
                  
              }

            if($filter_resume == '1')
            {

                $query->where('verified', 1);

          
            }
            if($filter_resume == '2')
            {
                $query->where('verified', 0);
            }
            if($filter_resume == '3')
            {
               
              
                    $query->where('package_end_date','>',$now);
           
            }
      
          
          $filter_users = $query->paginate(100);
    // dd($filter_users);


        Session::put('min_exp', $min_exp );
       
      //  Session::put('min1', $min );
        
        Session::put('max_exp', $max_exp );
        
        Session::put('interview_avail', $interview );
        
        Session::put('education', $education );
 
        Session::put('course', $course );
        
        Session::put('specilation', $specilation );
        
        Session::put('gender', $gender );
 
        Session::put('job_type', $job_type );

        Session::put('filter_resume', $filter_resume );

              $filter = 2;
      
      
      return view("company.candidate_listing",compact('filter_users','min_exp','max_exp','interview','education','job_type','gender','course','specilation','filter_resume','filter'));


    }

      
    }

    public function verifyemail($id)
    {
        $company=Company::where('id',$id)->first();   

        return view('company.email_verify',compact('company'));
    
        
    }

    public function companyemailverify($id)

    {

    $company=Company::where('id',$id)->first();

   // return dd($user);
 //  dd($company);

    $token = Str::random(64);
  
   
   $data =  CompanyVerify::create([
          'company_id' => $company->id, 
          'token' => $token,
        ]);

      // return dd($data);

    Mail::send('emails.company.emailVerificationEmail', ['token' => $token,'company'=>$company,'link' => URL::route('company.verify', $token)], function($message) use($company){
          $message->to($company->email);
          $message->subject('Confirm Your Email');
      });
     
 

         return redirect()->back()->with('success','Verification mail sent successfully to your email ID.');

    }

    public function verifyAccount($token)
    {
      
        $verifyCompany = CompanyVerify::where('token', $token)->first();

       // $db_user = new User();

        $db_user = Company::findOrFail(Auth::guard('company')->user()->id);

   // return dd($db_user);
  
        $message = 'Sorry your email cannot be identified.';

        if(!is_null($verifyCompany) ){

              
            if($db_user->email_verified != 1) {
                $db_user->email_verified = 1;
                $db_user->save();
                
               // return dd('saved');
                $message = "Your email has been verified";
                return view('companyverified')->with('message', $message);
            } else {
           
                $message = "It looks like you've already verified your email with us, thanks!.";
                return view('companyverified')->with('message', $message);
            }
        }
       
  
      return redirect()->route('employer.login')->with('new_message', $message);
    }


    public function gettemplate(Request $request)
    {
        $template = Template::where('id',$request->id)->first();

        return response()->json(['data'=>$template]);
    }

    public function emailtemplates()
    {
        $templates = Template::where('company_id',Auth::guard('company')->user()->id);
        $templates_count = $templates->count();
        $templates = $templates->get();
        return view('company.templates.list',compact('templates','templates_count'));
    }

    public function gettemplatedata(Request $request)
    {
        $template = Template::where('id',$request->id)->first();

        return response()->json(['result'=>$template]);
    }

    public function updatetemplatedata(Request $request)
    {   

       // dd($request->all());
       

        $validator = Validator::make($request->all(), [
          
            'templatename' => 'required|regex:/^[\pL\s\-]+$/u|max:255',           
            'subject' => 'required',
            'message' => 'required',
        ],[
          
            'templatename.required'  => 'Template name is required',
    
            'subject.required'  => 'Subject is required',
    
            'message.required'  => 'Description is required'
        ]);        

        if ($validator->passes()) {


            $template = Template::where('id',$request->id)->first();

            $template->templatename = $request->templatename;
            $template->subject = $request->subject;
            $template->message = $request->message;
            $template->save();

            return response()->json(array('success' => true, 'status' => 200), 200);
     
        }

        return response()->json(['errors'=>$validator->errors()]);


   

    }

    public function storetemplatedata(Request $request)
    {   

       // dd($request->all());
       

        $validator = Validator::make($request->all(), [
          
            'templatename' => 'required|regex:/^[\pL\s\-]+$/u|max:255',           
            'subject' => 'required',
            'message' => 'required',
        ],[
          
            'templatename.required'  => 'Template name is required',
    
            'subject.required'  => 'Subject is required',
    
            'message.required'  => 'Description is required'
        ]);        

        if ($validator->passes()) {


            $template = new Template();
            $template->templatename = $request->templatename;
            $template->subject = $request->subject;
            $template->message = $request->message;
            $template->company_id = Auth::guard('company')->user()->id;
            $template->save();

            return response()->json(array('success' => true, 'status' => 200), 200);
     
        }

        return response()->json(['errors'=>$validator->errors()]);


   

    }

public function deletetemplate(Request $request)
{
    $in = Template::where('id',$request->id)->delete();
    return 'ok';
}

}

