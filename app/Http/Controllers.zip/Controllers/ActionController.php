<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use App\User;
use App\Company;
use App\JobSkill;
use DB;
class ActionController extends Controller
{
    public function searchresumes(Request $request)
    {
       $company_id = Auth::guard('company')->user()->id;

      
    }

    public function getuserdata(Request $request)
    {

      $user = User::where('id',$request->user)->first();

      return response()->json(['user'=>$user]);

     
    }
    public function getcompanydata(Request $request)
    {

      // dd($request->all());

       if($request->user == 'all')
       {
      
        return view('admin.activites.employer_activities');

       }else{

        $companydata = Company::where('id',$request->user)->first();
        

        return view('admin.activites.employer_search',compact('companydata'));

       }

    }
    
     public function getskills(Request $request)
    {
    
        $q = $request->query;
        
        if(strlen($request->get('query')) >= 2)
        {

   
        $data1 =  JobSkill::where('job_skill', 'LIKE', "%{$request->get('query')}%")->select('job_skill')->get();
       
        $data = array();
        foreach ($data1 as $s) {
        
            array_push($data,$s->job_skill);
        }
        echo json_encode($data);
        
        }
      
     
    }
    
    
    
    
    public function checkEmail(Request $request)
    {
        $email = $request->input('email');

      //  dd($request->all());

        $user = User::where('email', $email)->first();

        if ($user) {
            return response()->json([
                'exists' => true
            ]);
        } else {
            return response()->json([
                'exists' => false
            ]);
        }
    }
    
    
    public function searchcompanies(Request $request)
    {
        $data = DB::table('company_data')
                ->select('id', 'name')
                ->where('name', 'like', '%' . $request->input('q') . '%')
                ->get();

        return response()->json($data);
    }
    
    public function searchuniversity(Request $request)
    {
        $data = DB::table('degrees')
                ->select('id', 'educations')
                ->where('educations', 'like', '%' . $request->input('q') . '%')
                ->get();

        return response()->json($data);
    }


}
